
#include "atun_mem.h"

static ncx_slab_pool_t *sp;
static ncx_slab_stat_t stat;
static u_char *space;

void atun_mem_init()
{
    size_t  pool_size = 4096000;  //2M
    space = (u_char *)malloc(pool_size);

    sp = (ncx_slab_pool_t *) space;

    sp->addr = space;
    sp->min_shift = 3;
    sp->end = space + pool_size;

    ncx_slab_init(sp);
}

void *atun_alloc(size_t size)
{
    return ncx_slab_alloc(sp, size);
}

void atun_alloc_free(void *p)
{
    ncx_slab_free(sp, p);
}

void atun_mem_stat()
{
    ncx_slab_stat(sp, &stat);
}

void atun_free()
{
    free(space);
}
