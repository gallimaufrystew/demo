/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   atun_ssl.h
 * Author: 19020107
 *
 * Created on April 29, 2018, 5:57 PM
 */

#ifndef ATUN_SSL_H
#define ATUN_SSL_H

#include <openssl/ssl.h>
#include <openssl/err.h>

class atun_ssl {

    atun_ssl(int fd)
    : verify_peer(false),
    connected_(false),
    //fd_(fd),
    ssl(nullptr),
    old_ctx(nullptr),
    new_ctx(nullptr) {

        SSL_library_init();
        SSL_load_error_strings();
        
        new_ctx = create_context("sha2");
        old_ctx = create_ssl_ctx("sha2");
        
        ssl = SSL_new(old_ctx);
        if (!ssl) {
            std::printf("SSL_new() fail\n");
            return -1;
        }

        SSL_set_fd(ssl, fd_);
    }
    
    bool is_connected() const {
        return connected;
    }
    
    SSL* get_ssl() {
        return ssl;
    }
    
    bool verify() const {
        return verify_peer;
    }
    
    void set_connected(bool connected) {
        connected_ = connected;
    }

    ~atun_ssl() {

        SSL_shutdown(ssl);

        SSL_CTX_free(old_ctx);
        SSL_CTX_free(new_ctx);
        SSL_free(ssl);
    }
    
    int handle_ssl_write() {
        
        return 0;
    }
    
    int handle_ssl_read() {
        
        return 0;
    }

    SSL_CTX *create_context(const char *sign_algo) {
        SSL_CTX *ctx = nullptr;
        char file_name[512] = {0};

        ctx = SSL_CTX_new(SSLv23_server_method());
        if (!ctx) {
            ERR_print_errors_fp(stderr);
            return nullptr;
        }

        //SSL_CTX_set_mode(ctx, SSL_MODE_AUTO_RETRY);
        SSL_CTX_set_default_passwd_cb_userdata(ctx, (void *) passwd);
        SSL_CTX_add_server_custom_ext(ctx, CUSTOM_EXT_TYPE_1000,
                nullptr, nullptr, nullptr, ana_ext_callback, this);

        sprintf(file_name, "server_%s.crt", sign_algo);

#if (1)
        //SSL_CTX_use_certificate_chain_file
        if (SSL_CTX_use_certificate_file(ctx, file_name, SSL_FILETYPE_PEM)
                <= 0) {
            //printf("SSL_CTX_use_certificate_file() fail");
            ERR_print_errors_fp(stderr);
            return nullptr;
        }
#else
        X509 *x509 = load_cert(file_name);

        if (SSL_CTX_use_certificate(ssl_ctx, x509) <= 0) {
            //printf("SSL_CTX_use_certificate_file() fail");
            ERR_print_errors_fp(stderr);
            return nullptr;
        }
        X509_free(x509);
#endif

        sprintf(file_name, "server_%s.key", sign_algo);
        if (SSL_CTX_use_PrivateKey_file(ctx, file_name, SSL_FILETYPE_PEM)
                <= 0) {
            //printf("SSL_CTX_use_PrivateKey_file() fail");
            ERR_print_errors_fp(stderr);
            return nullptr;
        }

        if (SSL_CTX_check_private_key(ctx) != 1) {
            //printf("Private and certificate is not matching\n");
            ERR_print_errors_fp(stderr);
            return nullptr;
        }

#if (1)
        SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, nullptr);
        // we can string certs together to form a cert-chain
        sprintf(file_name, "ca_%s.crt", sign_algo);
        if (!SSL_CTX_load_verify_locations(ctx, file_name, nullptr)) {
            ERR_print_errors_fp(stderr);
            return nullptr;
        }
        SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, nullptr);

        //SSL_CTX_set_verify_depth(ctx, 1);
        //SSL_CTX_set_tlsext_servername_callback(ctx, svr_name_callback);
#endif

        return ctx;
    }

    static int ana_ext_callback(SSL *ssl, unsigned int ext_type,
            const unsigned char *in, size_t inlen, int *al, void *arg) {
        char ext_buf[2048] = {0};
        char *tag = nullptr;
        char cust_tag[1024] = {0};

        std::memcpy(ext_buf, in, inlen);

        //printf("---ext parse callback---\n");

        tag = strstr(ext_buf, "sign_algo=");
        if (tag) {
            sprintf(cust_tag, "%s", tag + strlen("sign_algo="));
        }

        printf("---cert tag [%s]----\n", cust_tag);

        atun_ssl *session = (atun_ssl *) arg;

        SSL_set_SSL_CTX(ssl, session->new_ctx);

        return 1;
    }

private:

    bool verify_peer;
    bool connected_;
    //int fd_;
    SSL *ssl;
    //int client;
    SSL_CTX *old_ctx;
    SSL_CTX *new_ctx;
};

#endif /* ATUN_SSL_H */
