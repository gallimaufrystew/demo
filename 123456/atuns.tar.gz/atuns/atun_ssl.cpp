
#include "atun_ssl.h"

static int ana_ext_callback(SSL *ssl, unsigned int ext_type,
    const unsigned char *in, size_t inlen, int *al, void *arg);
static SSL_CTX *create_context(const char *sign_algo);

static int atun_ssl_verify(atun_event_t *ev);
static int atun_ssl_read_head(atun_event_t *ev);
static int atun_connect_upstream(atun_event_t *ev);
static bool connection_is_new(atun_connection_t *c);
static int atun_ssl_read_body(atun_event_t *ev);

static const char *passwd = "123456", *rfb_command = "RFB_OPEN";
static const int rfb_listen_port = 5900;

static ssl_session_t *ssl_session;

extern port_map_t port_map;

void atun_init_ssl_lib()
{
    SSL_library_init();
    SSL_load_error_strings();
}

void atun_ssl_free()
{
    SSL_shutdown(ssl_session->ssl);
    SSL_CTX_free(ssl_session->old_ctx);
    SSL_CTX_free(ssl_session->new_ctx);
    SSL_free(ssl_session->ssl);
}

int atun_init_ssl_session()
{
    auto size = sizeof(ssl_session_t);
    ssl_session = static_cast<ssl_session_t*>(atun_alloc(size));
    if (!ssl_session) {
        std::printf("atun_alloc -> ssl_session fail\n");
        return -1;
    }

    ssl_session->verify_peer = false;

    ssl_session->new_ctx = create_context("sha2");
    ssl_session->old_ctx = create_context("sha2");
    ssl_session->ssl = SSL_new(ssl_session->old_ctx);
    if (!ssl_session->ssl) {
        std::printf("SSL_new() fail\n");
        return -1;
    }

    return 0;
}

int atun_ssl_handshake(atun_event_t *ev)
{
    atun_connection_t *c = static_cast<atun_connection_t*>(ev->data);

    SSL_set_fd(ssl_session->ssl, c->fd);
    SSL_set_accept_state(ssl_session->ssl);

    //ERR_clear_error();

    int n = SSL_do_handshake(ssl_session->ssl);
    if (n <= 0) {
        ERR_print_errors_fp(stderr);
        int err = SSL_get_error(ssl_session->ssl, n);
        if (err == SSL_ERROR_WANT_READ || err == SSL_ERROR_WANT_WRITE) {
            std::cout << "atun_ssl_handshake again " << "\n";
            return 0;
        }
        std::cout <<  __func__ << " fatal " << err << "\n";
        return -1;
    }

    std::cout << "atun_ssl_handshake 1 " << "\n";

    ev->handler = atun_ssl_verify;

    return 0;
}

int atun_ssl_verify(atun_event_t *ev)
{
    atun_connection_t *c = static_cast<atun_connection_t*>(ev->data);

std::cout << "atun_ssl_handshake 1 " << "\n";

    if (ssl_session->verify_peer) {
        X509 *cert = SSL_get_peer_certificate(ssl_session->ssl);
        if (!cert) {
            std::cout << "no peer certificate\n";
            return -1;
        }
        long ret = SSL_get_verify_result(ssl_session->ssl);
        if (ret != X509_V_OK) {
            ERR_print_errors_fp(stderr);
            return -1;
        }
        X509_free(cert);
    }

std::cout << "atun_ssl_handshake 1 " << "\n";

    //atun_connection_t *c = get_connection();
    //acon->handler = atun_event_accept;
    //acon->fd = fd;
    //acon->read_event->write = 1;
    //acon->obuf = atun_alloc(81920);
    //acon->ibuf = atun_alloc(81920);

    c->read_event->handler = atun_ssl_read_head;
    //c->write_event->handler = atun_ssl_write;
    c->buf = static_cast<u_char*>(atun_alloc(PROTO_SIZE));
    c->last = c->buf;
    c->left = PROTO_SIZE;
    //atun_select_add_event(acon->read_event, ATUN_READ_EVENT, 0);
    //atun_select_add_event(acon->write_event, ATUN_WRITE_EVENT, 0);

    return 0;
}

bool connection_is_new(atun_connection_t *c)
{
    auto it = c->uplnks.find(c->suid);
    if (it == std::end(c->uplnks)) {
        return true;
    }
    return false;
}

int atun_ssl_read_head(atun_event_t *ev)
{
    atun_connection_t *c = static_cast<atun_connection_t*>(ev->data);

    int n = SSL_read(ssl_session->ssl, c->last, c->left);
    if (n <= 0) {
        int err = SSL_get_error(ssl_session->ssl, n);
        if (err == SSL_ERROR_WANT_READ || err == SSL_ERROR_WANT_WRITE) {
            return 0;
        }
        std::cout <<  __func__ << " fatal " << err << "\n";
        return -1;
    }
    c->left -= n;
    c->last += n;
    if (c->left == 0) {

        uint32_t  len, nlen;
        memcpy(&nlen, c->buf, 4);
        len = ntohl(nlen);

        uint32_t  nport;
        memcpy(&nport, c->buf + 4, 4);
        c->port = ntohl(nport);

        uint32_t  nsuid;
        memcpy(&nsuid, c->buf + 8, 4);
        c->suid = ntohl(nsuid);

        atun_alloc_free(c->buf);

        if (connection_is_new(c)) {
            c->read_event->handler = atun_connect_upstream;
        } else {
            c->left = len;
            c->buf = static_cast<u_char*>(atun_alloc(len));
            c->last = c->buf;
            c->read_event->handler = atun_ssl_read_body;
        }
    }
    return 0;
}

int atun_ssl_read_body(atun_event_t *ev)
{
    atun_connection_t *c = static_cast<atun_connection_t*>(ev->data);

    ERR_clear_error();

    int n = SSL_read(ssl_session->ssl, c->last, c->left);
    if (n <= 0) {
        int err = SSL_get_error(ssl_session->ssl, n);
        if (err == SSL_ERROR_WANT_READ || err == SSL_ERROR_WANT_WRITE) {
            return 0;
        } else {
            // todo fatal error
            std::cout <<  __func__ << " " << err << "\n";
            return -1;
        }
    }
    c->left -= n;
    c->last += n;
    if (c->left == 0) {

        auto host = port_map[c->port];

        if (host.second == rfb_listen_port &&
            memcmp(c->buf, rfb_command, std::strlen(rfb_command)) == 0) {
            return 0;
        }

            size_t size = c->last - c->buf;
            u_char *data = static_cast<u_char*>(atun_alloc(size)), *last = data;
            std::memcpy(data, c->buf, size);
            atun_connection_t *up = c->uplnks[c->suid];
            up->queue.push_back(std::make_pair(last, size));

            atun_alloc_free(c->buf);
            c->left = PROTO_SIZE;
            c->buf = static_cast<u_char*>(atun_alloc(PROTO_SIZE));
            c->last = c->buf;
            c->read_event->handler = atun_ssl_read_head;
    }
    return 0;
}

int atun_ssl_write(atun_event_t *ev)
{
    atun_connection_t *c = static_cast<atun_connection_t*>(ev->data);
    auto queue = c->queue;

    if (!queue.empty()) {
        auto item = queue.front();
        queue.pop_front();
        auto n = SSL_write(ssl_session->ssl, item.first, item.second);
        if (n <= 0) {
            int err = SSL_get_error(ssl_session->ssl, n);
            if (err == SSL_ERROR_WANT_READ || err == SSL_ERROR_WANT_WRITE) {
                queue.push_front(item);
                return 0;
            }
            // todo fatal error
            std::cout <<  __func__ << " " << err << "\n";
            return -1;
        }

        if (n < item.second) {
            item.second -= n;
            item.first += n;
            queue.push_front(item);
        }
    }
    return 0;
}

int atun_connect_upstream(atun_event_t *ev)
{
    atun_connection_t *c = static_cast<atun_connection_t*>(ev->data);

    auto host = port_map[c->port];

    int n = async_connect(host.first, host.second);
    if (n <= 0) {
        std::cout << "async_connect_upstream" << "\n";
        return -1;
    }

    atun_connection_t *uc = get_connection();

    uc->fd = n;
    atun_event_t *rev = uc->read_event;
    atun_event_t *wev = uc->write_event;

    rev->data = uc;
    rev->write = 0;
    wev->data = uc;
    wev->write = 1;

    uc->down = c;
    uc->suid = c->suid;

    rev->handler = atun_upstream_read;
    wev->handler = atun_upstream_write;

    atun_select_add_event(rev, ATUN_READ_EVENT, 0);
    atun_select_add_event(wev, ATUN_WRITE_EVENT, 0);

    c->uplnks[c->suid] = uc;
    c->write_event->handler = atun_ssl_write;

    atun_select_add_event(c->write_event, ATUN_WRITE_EVENT, 0);

    return 0;
}

static SSL_CTX *create_context(const char *sign_algo)
{
    SSL_CTX *ctx = nullptr;
    char file_name[512] = {0};

    ctx = SSL_CTX_new(SSLv23_server_method());
    if (!ctx) {
        ERR_print_errors_fp(stderr);
        return nullptr;
    }

    //SSL_CTX_set_mode(ctx, SSL_MODE_AUTO_RETRY);
    SSL_CTX_set_default_passwd_cb_userdata(ctx, (void *) passwd);
    SSL_CTX_add_server_custom_ext(ctx, CUSTOM_EXT_TYPE_1000,
        nullptr, nullptr, nullptr, ana_ext_callback, ssl_session);

    sprintf(file_name, "server_%s.crt", sign_algo);

#if (1)
    //SSL_CTX_use_certificate_chain_file
    if (SSL_CTX_use_certificate_file(ctx, file_name, SSL_FILETYPE_PEM)
            <= 0) {
        //printf("SSL_CTX_use_certificate_file() fail");
        ERR_print_errors_fp(stderr);
        return nullptr;
    }
#else
    X509 *x509 = load_cert(file_name);

    if (SSL_CTX_use_certificate(ssl_ctx, x509) <= 0) {
        //printf("SSL_CTX_use_certificate_file() fail");
        ERR_print_errors_fp(stderr);
        return nullptr;
    }
    X509_free(x509);
#endif

    sprintf(file_name, "server_%s.key", sign_algo);
    if (SSL_CTX_use_PrivateKey_file(ctx, file_name, SSL_FILETYPE_PEM)
            <= 0) {
        //printf("SSL_CTX_use_PrivateKey_file() fail");
        ERR_print_errors_fp(stderr);
        return nullptr;
    }

    if (SSL_CTX_check_private_key(ctx) != 1) {
        //printf("Private and certificate is not matching\n");
        ERR_print_errors_fp(stderr);
        return nullptr;
    }

#if (1)
    //SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, nullptr);
    // we can string certs together to form a cert-chain
    sprintf(file_name, "ca_%s.crt", sign_algo);
    if (!SSL_CTX_load_verify_locations(ctx, file_name, nullptr)) {
        ERR_print_errors_fp(stderr);
        return nullptr;
    }
    SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, nullptr);

    //SSL_CTX_set_verify_depth(ctx, 1);
    //SSL_CTX_set_tlsext_servername_callback(ctx, svr_name_callback);
#endif

    return ctx;
}

static int ana_ext_callback(SSL *ssl, unsigned int ext_type,
                            const unsigned char *in, size_t inlen, int *al, void *arg)
{
    char ext_buf[2048] = {0};
    char *tag = nullptr;
    char cust_tag[1024] = {0};

    std::memcpy(ext_buf, in, inlen);

    //printf("---ext parse callback---\n");

    tag = strstr(ext_buf, "sign_algo=");
    if (tag) {
        sprintf(cust_tag, "%s", tag + strlen("sign_algo="));
    }

    printf("---cert tag [%s]----\n", cust_tag);

    ssl_session_t *session = (ssl_session_t *) arg;

    SSL_set_SSL_CTX(ssl, session->new_ctx);

    return 1;
}
