/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   atun_select.h
 * Author: 19020107
 *
 * Created on April 29, 2018, 4:19 PM
 */

#ifndef ATUN_SELECT_H
#define ATUN_SELECT_H

#include <stdint.h>

typedef int             atun_err_t;
typedef intptr_t        atun_int_t;
typedef uintptr_t       atun_uint_t;

#define  ATUN_INVALID_INDEX  0xd0d0d0d0

#define ATUN_READ_EVENT     0
#define ATUN_WRITE_EVENT    1

#define ATUN_TIMER_INFINITE  (atun_int_t) -1

#define atun_errno                  errno
#define atun_socket_errno           errno

#endif /* ATUN_SELECT_H */
