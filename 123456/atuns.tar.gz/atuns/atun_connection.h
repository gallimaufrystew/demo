
#ifndef ATUN_CONNECTION_H_INCLUDED
#define ATUN_CONNECTION_H_INCLUDED

#include "atun_event.h"
#include "atun_mem.h"
#include "atun_select.h"

typedef std::list<atun_connection_t *> connection_list;

void atun_init_connection(int max_conns = MAX_CONNECTIONS);
atun_connection_t* get_connection();
void atun_free_connection(atun_connection_t *c);
int atun_event_accept(atun_event_t *ev);
int atun_upstream_read(atun_event_t *ev);
int atun_upstream_write(atun_event_t *ev);

#endif
