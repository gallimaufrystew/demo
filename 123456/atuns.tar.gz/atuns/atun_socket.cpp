/*
 * tun_socket.cc
 */

#include "atun_socket.h"
#include "atun_connection.h"
#include "atun_select.h"
#include "config.h"

extern port_map_t port_map;

static int connect_backend(int fd, sockaddr *addr, socklen_t sock_len);

int init_listen_socket()
{
    int fd;
    struct sockaddr_in addr = {};

    //memset(&addr, 0, sizeof(struct sockaddr_in));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port_map[443].second);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);

    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        std::printf("socket() ERR");
        exit(EXIT_FAILURE);
    }

    int on = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(int));

    if (bind(fd, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
        std::printf("bind() ERR");
        exit(EXIT_FAILURE);
    }

    if (listen(fd, 5) < 0) {
        std::printf("listen() ERR");
        exit(EXIT_FAILURE);
    }

    atun_set_nonblock(fd);

    atun_connection_t *c = get_connection();
    if (c == nullptr) {
        std::cout << "init_listen_socket -> get_connection -> fail";
        return -1;
    }

    c->fd = fd;
    c->read_event->accept = 1;
    c->read_event->write = 0;
    c->read_event->index = ATUN_INVALID_INDEX;
    c->read_event->handler = atun_event_accept;

    atun_select_add_event(c->read_event, ATUN_READ_EVENT, 0);

    return 0;
}

static void *fill_in_addr(struct sockaddr *sa)
{
    if (sa->sa_family == AF_INET) {
        return &(((struct sockaddr_in *)sa)->sin_addr);
    }

    return &(((struct sockaddr_in6 *)sa)->sin6_addr);
}

int async_connect(std::string &host, int port)
{
    int   fd, rv;
    struct addrinfo hints = {}, *sainfo, *p;
    char  addr_text[INET6_ADDRSTRLEN] = {};

    hints.ai_family = AF_INET;// AF_UNSPEC AF_INET6
    hints.ai_socktype = SOCK_STREAM;

    char service[128] = {0};
    std::sprintf(service, "%d", port);

    if ((rv = getaddrinfo(host.c_str(), service, &hints, &sainfo)) != 0) {
        fprintf(stderr, "server getaddrinfo: %s\n", gai_strerror(rv));
        return -1;
    }

    for (p = sainfo; p ; p = p->ai_next) {

        if ((fd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
            perror("server socket");
            continue;
        }

        if (connect_backend(fd, p->ai_addr, p->ai_addrlen)) {
            perror("server connect");
            close(fd);
            continue;
        }

        /*
                if (connect(fd, p->ai_addr, p->ai_addrlen) == -1) {
                    perror("server connect");
                    close(fd);
                    continue;
                }
        */
        break;
    }

    if (p == nullptr) {
        fprintf(stderr, "failed to connect to upstream\n");
        return -1;
    }

    void *addr = fill_in_addr((struct sockaddr *)p->ai_addr);
    inet_ntop(p->ai_family, addr, addr_text, sizeof(addr_text));

    std::cout << "connection to upstream " << addr_text << "\n";

    freeaddrinfo(sainfo);

    return fd;
}

static int connect_backend(int fd, sockaddr *addr, socklen_t sock_len)
{
    int rc = connect(fd, addr, sock_len);
    if (rc != 0) {

        if (errno == EINPROGRESS) {

            fd_set rset, wset;
            struct timeval tv = {10, 0};

            FD_ZERO(&rset);
            FD_ZERO(&wset);

            FD_SET(fd, &rset);
            FD_SET(fd, &wset);

            rc = select(fd + 1, &rset, &wset, NULL, &tv);
            if (rc <= 0) {
                std::fprintf(stderr, "connect ERR: %s\n", strerror(errno));
                atun_close_sock(fd);
                return -1;
            }

            if (rc == 1 && FD_ISSET(fd, &wset)) {
                std::cout << "connect success\n";
                //socket_block(fd);
                return 0;
            } else if (rc == 2) {
                int err = 0;
                socklen_t len = sizeof(err);
                if (getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &len) == -1) {
                    std::fprintf(stderr, "getsockopt(SO_ERROR): %s", strerror(errno));
                    atun_close_sock(fd);
                    return -1;
                }
                if (err) {
                    errno = err;
                    std::fprintf(stderr, "connect ERR: %s\n", strerror(errno));
                    atun_close_sock(fd);
                    return -1;
                }
            }
        }
        std::fprintf(stderr, "connect ERR: %s\n", strerror(errno));
        return -1;
    }

    return 0;
}

int atun_close_sock(int fd)
{
#if __linux__
    close(fd);
#elif _WIN32
    closesocket(fd);
#endif
}

#if __linux__

int atun_set_nonblock(int fd)
{
    int  nb = 1;
    return ioctl(fd, FIONBIO, &nb);
}

int atun_set_block(int fd)
{
    int nb = 0;
    return ioctl(fd, FIONBIO, &nb);
}

#elif _WIN32

int atun_set_nonblock(int fd)
{
    unsigned long  nb = 1;
    return ioctlsocket(s, FIONBIO, &nb);
}

int atun_set_block(int fd)
{
    unsigned long  nb = 0;
    return ioctlsocket(s, FIONBIO, &nb);
}

#endif
