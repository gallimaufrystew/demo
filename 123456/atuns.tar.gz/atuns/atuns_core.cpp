///
/// help function
///

#if (0)

#ifndef HELP_INCLUDED_CC_
#define HELP_INCLUDED_CC_

#include "tuns_core.h"
#include "config.h"

const char *passwd = "123456", *rfb_command = "RFB_OPEN";

const int rfb_listen_port = 5900;

uid2fd_map_t connections;
fd2uid_map_t fd2uid;
extern port_map_t port_map;

static int ana_ext_callback(SSL *ssl, unsigned int ext_type,
                            const unsigned char *in, size_t inlen, int *al, void *arg);
static int timeout_accept(int fd);
int exact_write(int fd, void *buf, int len);
int ssl_exact_write(SSL *ssl, void *buf, int len);
int ssl_exact_read(SSL *ssl, void *buf, int len);
int is_socket_valid(int suid, uid2fd_map_t &conns, fd_set &rset);
void add_read_set(int fd, fd_set &rset);

int handle_rfb_channel_message(int suid, int port, char client_data[], int len);
int handle_other_channel_message(int suid, int port, char client_data[], int len);

int add_valid_socket(uid2fd_map_t &conns, fd_set &rset)
{
    int maxfd = 0;

    FD_ZERO(&rset);

    for (auto it = conns.begin(); it != conns.end(); ++it) {

        auto fd_state = it->second;
        if (fd_state.second) {

            if (is_socket_valid(it->first, conns, rset)) {
                continue;
            }

            add_read_set(fd_state.first, rset);

            maxfd = std::max(maxfd, fd_state.first);

        } else {
            //close_sock(fd_state.first);
        }
    }
    return maxfd;
}

int is_socket_valid(int suid, uid2fd_map_t &conns, fd_set &rset)
{
    int         n, fd = conns[suid].first;
    socklen_t   len = sizeof(int);

    if (getsockopt(fd, SOL_SOCKET, SO_TYPE, (char *) &n, &len) == -1) {
        //close_sock(fd);
        FD_CLR(fd, &rset);
        conns[suid] = std::make_pair(fd, false);
        return -1;
    }
    return 0;
}

void add_read_set(int fd, fd_set &rset)
{
    struct timeval tv = {10, 0};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, (char *)&tv, sizeof(tv));
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, (char *)&tv, sizeof(tv));
    FD_SET(fd, &rset);
}

int exact_write(int fd, void *buf, int len)
{
    int    bytes_left, written_bytes;
    char  *ptr = static_cast<char *>(buf);

    bytes_left = len;

    while (bytes_left > 0) {
        written_bytes = send(fd, ptr, bytes_left, 0);
        if (written_bytes <= 0) {
            if (errno == EINTR || errno == EWOULDBLOCK || errno == EAGAIN) {
                written_bytes = 0;
            } else {
                // todo fatal error
                std::cout << __func__ << " " << strerror(errno) << "\n";
                return -1;
            }
        }
        bytes_left -= written_bytes;
        ptr += written_bytes;
    }
    return 0;
}

int ssl_exact_read(SSL *ssl, void *buf, int len)
{
    int    bytes_left, bytes_read;
    char  *ptr = static_cast<char *>(buf);

    bytes_left = len;

    while (bytes_left > 0) {
        bytes_read = SSL_read(ssl, ptr, bytes_left);
        if (bytes_read <= 0) {
            int err = SSL_get_error(ssl, bytes_read);
            if (err == SSL_ERROR_WANT_READ || err == SSL_ERROR_WANT_WRITE) {
                bytes_read = 0;
            } else {
                // todo fatal error
                std::cout <<  __func__ << " " << err << "\n";
                return -1;
            }
        }
        bytes_left -= bytes_read;
        ptr += bytes_read;
    }
    return 0;
}

int ssl_exact_write(SSL *ssl, void *buf, int len)
{
    int    bytes_left, written_bytes;
    char  *ptr = static_cast<char *>(buf);

    bytes_left = len;

    while (bytes_left > 0) {
        written_bytes = SSL_write(ssl, ptr, bytes_left);
        if (written_bytes <= 0) {
            int err = SSL_get_error(ssl, written_bytes);
            if (err == SSL_ERROR_WANT_READ || err == SSL_ERROR_WANT_WRITE) {
                written_bytes = 0;
            } else {
                // todo fatal error
                std::cout <<  __func__ << " " << err << "\n";
                return -1;
            }
        }
        bytes_left -= written_bytes;
        ptr += written_bytes;
    }
    return 0;
}


int handle_upstream_read(int fd, ssl_session_t &session)
{
    char buf[PROTO_HEAD_SIZE + USER_MSG_SIZE] = { 0 };

    int len = recv(fd, buf + PROTO_HEAD_SIZE, USER_MSG_SIZE, 0);
    if (len <= 0) {
        if (errno != EINTR && errno != EWOULDBLOCK && errno != EAGAIN) {
            // close_sock(fd);
            // fd was reused by os
            uint32_t suid = fd2uid[fd];
            connections[suid] = std::make_pair(fd, false);
        }
        return -1;
    }

    //std::cout << "upstream data size <--- " << len << '\n';

    uint32_t  nlen;
    nlen = htonl(len);
    memcpy(buf, &nlen, 4);

    // now port is of no importance
    // for simplicity we omit it

    // which session ?
    /// tricky part...

    uint32_t nsuid;
    nsuid = htonl(fd2uid[fd]);
    memcpy(buf + 8, &nsuid, 4);

    int n = ssl_exact_write(session.ssl, buf, len + PROTO_HEAD_SIZE);
    if (n != 0) {
        session.connected = false;
        return -1;
    }

    return 0;
}

int handle_ssl_read(ssl_session_t &session)
{
    char buf[PROTO_HEAD_SIZE + USER_MSG_SIZE] = { 0 };

    int n = ssl_exact_read(session.ssl, buf, PROTO_HEAD_SIZE);
    if (n != 0) {
        session.connected = false;
        return -1;
    }

    uint32_t  len, nlen;
    memcpy(&nlen, buf, 4);
    len = ntohl(nlen);

    uint32_t  port, nport;
    memcpy(&nport, buf + 4, 4);
    port = ntohl(nport);

    uint32_t  suid, nsuid;
    memcpy(&nsuid, buf + 8, 4);
    suid = ntohl(nsuid);

    n = ssl_exact_read(session.ssl, buf + PROTO_HEAD_SIZE, len);
    if (n != 0) {
        session.connected = false;
        return -1;
    }

    if (connection_is_new(suid)) {

        int up_fd = open_upstream(port);
        if (up_fd <= 0) {
            return -1;
        }

        std::cout << "new upstream " << up_fd << "\n";
        connections[suid] = std::make_pair(up_fd, true);

        auto xit = fd2uid.find(up_fd);
        if (xit != std::end(fd2uid)) {
            std::cout << "reused...\n";
        }

        fd2uid[up_fd] = suid;
        if (port_map[port].second == rfb_listen_port) {
            return up_fd;
        }
    }

    auto fd_state = connections[suid];
    int ret = exact_write(fd_state.first, buf + PROTO_HEAD_SIZE, len);
    if (ret != 0) {
        connections[suid] = std::make_pair(fd_state.first, false);
    }

    return ret;

#if (0)
    if (port_map[port].second == rfb_listen_port) {
        return handle_rfb_channel_message(suid, port, buf + PROTO_HEAD_SIZE, len);
    } else {
        return handle_other_channel_message(suid, port, buf + PROTO_HEAD_SIZE, len);
    }
#endif
}

#if (0)
int handle_rfb_channel_message(int suid, int port, char rfb_data[], int len)
{
    int cmd_len = strlen(rfb_command);
    if (memcmp(rfb_data, rfb_command, cmd_len) == 0) {
        int up_fd = open_upstream(port);
        if (up_fd > 0) {
            std::cout << "rfb command open socket " << up_fd << "\n";
            connections[suid] = std::make_pair(up_fd, true);
            fd2uid[up_fd] = suid;
            //connections[up_fd] = true;
        }
        return up_fd;
    } else {
        auto fd_state = connections[suid];
        if (fd_state.second) {
            /// int up_fd = connections[suid].first;
            int ret = exact_write(fd_state.first, rfb_data, len);
            if (ret != 0) {
                connections[suid] = std::make_pair(fd_state.first, false);
            }
            return ret;
        } else {

            /// the upstream has broken
            /// there's no way to fix it, drop the packets
            /// client should reinitiate the connection

            /*
            close_sock(fd_state.first);
            int up_fd = open_upstream(port);
            if (up_fd > 0) {
                std::cout << "reopen >>> " << up_fd << "\n";
                connections[suid] = std::make_pair(up_fd, true);
                fd2uid[up_fd] = suid;
                int ret = exact_write(up_fd, rfb_data, len);
                if (ret != 0) {
                   connections[suid] = std::make_pair(fd_state.first, false);
                }
                return ret;
            }
            */
        }
    }
}

int handle_other_channel_message(int suid, int port, char other_data[], int len)
{
    auto it = connections.find(suid);
    if (it == std::end(connections)) {

        std::cout << "other client " << "suid = " << suid << " port " << port << "\n";

        int ret, up_fd = open_upstream(port);
        if (up_fd > 0) {
            connections[suid] = std::make_pair(up_fd, true);
            fd2uid[up_fd] = suid;
            //connections[up_fd] = true;
            ret = exact_write(up_fd, other_data, len);
            if (ret != 0) {
                connections[suid] = std::make_pair(up_fd, false);
            }
            return ret;
        }
        return up_fd;
    } else {
        auto fd_state = connections[suid];
        if (fd_state.second) {
            /// int up_fd = connections[suid].first;
            int ret = exact_write(fd_state.first, other_data, len);
            if (ret != 0) {
                connections[suid] = std::make_pair(fd_state.first, false);
            }
            return 0;
        } else {

            /// the upstream has broken
            /// there's no way to fix it, drop the packets
            /// client should reinitiate the connection

            /*
            close_sock(fd_state.first);
            int up_fd = open_upstream(port);
            if (up_fd > 0) {
                std::cout << "reopen >>> " << up_fd << "\n";
                connections[suid] = std::make_pair(up_fd, true);
                fd2uid[up_fd] = suid;
                int ret = exact_write(up_fd, other_data, len);
                if (ret != 0) {
                   connections[suid] = std::make_pair(fd_state.first, false);
                }
                return ret;
            }
            */
        }
    }
}
#endif

static int valid_ip(const std::string &host, sockaddr_in &sa)
{
    int res = inet_pton(AF_INET, host.c_str(), &(sa.sin_addr));
    return res == 1;
}

// connect by ipaddr or hostname
int open_upstream(int port)
{
    auto value = port_map[port];
    struct sockaddr_in addr = {};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(value.second);

    if (valid_ip(value.first, addr)) {
        int fd = socket(AF_INET, SOCK_STREAM, 0);
        if (fd < 0) {
            std::printf("socket() ERR");
            return -1;
        }
        if (timeout_connect(fd, (struct sockaddr *)&addr, sizeof(addr))) {
            perror("server connect");
            close_sock(fd);
            return -1;
        }
        return fd;
    }
    return connect_by_hostname(value.first, value.second);
}

int init_libssl()
{


    return 0;
}

int init_ssl_service()
{
    init_libssl();

    init_port_mapping();

    return open_socket(port_map[443].second);
}

void clean_up_ssl(ssl_session_t &sess)
{


    close(sess.client);
}

void clean_up(ssl_session_t &sess)
{
    clean_up_ssl(sess);

    for (auto it = connections.begin(); it != connections.end(); ++it) {
        close(it->second.first);
    }

    connections.clear();
    //up_connections.clear();
    fd2uid.clear();
    port_map.clear();
}

static int timeout_accept(int fd)
{
    fd_set rset;
    struct timeval tv = {5, 0};

    FD_ZERO(&rset);
    FD_SET(fd, &rset);
    int ret = select(fd + 1, &rset, nullptr, nullptr, &tv);
    if (ret > 0) {
        return accept(fd, nullptr, 0);
    }

    return -1;
}


#if (0)
static X509 *load_cert(const char *file)
{
    X509 *x = nullptr;
    BIO *err = nullptr, *cert = nullptr;

    cert = BIO_new(BIO_s_file());
    if (cert == nullptr) {
        ERR_print_errors(err);
        goto end;
    }

    if (BIO_read_filename(cert, file) <= 0) {
        BIO_printf(err, "Error opening %s\n", file);
        ERR_print_errors(err);
        goto end;
    }

    x = PEM_read_bio_X509_AUX(cert, nullptr, nullptr, nullptr);

end:
    if (x == nullptr) {
        BIO_printf(err, "unable to load certificate\n");
        ERR_print_errors(err);
    }
    if (cert != nullptr) {
        BIO_free(cert);
    }
    return (x);
}

static int svr_name_callback(SSL *ssl, int *a, void *b)
{
    if (!ssl) {
        return SSL_TLSEXT_ERR_NOACK;
    }

    const char *svrname = SSL_get_servername(ssl, TLSEXT_NAMETYPE_host_name);
    if (!svrname || svrname[0] == '\0') {
        return SSL_TLSEXT_ERR_NOACK;
    }

    /* loading certificate based on sni */
    printf("svrname:%s\n", svrname);

    return SSL_TLSEXT_ERR_OK;
}
#endif


#if (0)
static int cert_callback(SSL *ssl, void *a)
{

    printf("------certificate callback %p-------\n", ssl_new_ctx);

    //SSL_set_SSL_CTX(ssl, ssl_new_ctx);

#if (0)
    SSL_set_verify(ssl, SSL_CTX_get_verify_mode(ssl_new_ctx),
                   SSL_CTX_get_verify_callback(ssl_new_ctx));

    SSL_set_options(ssl, SSL_CTX_get_options(ssl_new_ctx));
#endif

    return 1;
}
#endif

#endif /* TUNS_CORE_INCLUDED_H_ */

#endif
