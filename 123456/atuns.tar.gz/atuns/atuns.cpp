///
/// File:   atuns.cpp
/// Author: xingkanhu
///

#include "atun_signal.h"
#include "config.h"
#include "atun_socket.h"
#include "atun_mem.h"
#include "atun_connection.h"
#include "atun_ssl.h"

//int event_process(fd_set &fdset, uid2fd_map_t &conns, ssl_session_t &ssl_session);
//int handle_read_ssl_client(uid2fd_map_t &conns, ssl_session_t &ssl_session);
//int handle_ssl_accept_event(uid2fd_map_t &conns, ssl_session_t &ssl_session);

//extern uid2fd_map_t connections;
extern sig_atomic_t sig_exit;

int main(int argc, char *argv[])
{
    init_config();

    init_signal();

    atun_mem_init();

    atun_select_init();

    atun_init_connection();

#if (0)
        int maxfd = ssl_session.fd = init_ssl_service();
        connections[1] = std::make_pair(ssl_session.fd,true);

        std::cout << "ssl fd " << ssl_session.fd << "\n";
#endif

    int n = init_listen_socket();
    if (n != 0) {
        std::cout << "init_listen_socket...\n";
        return -1;
    }
    atun_init_ssl_lib();
    
    std::cout << "start handling event...\n";

    for (;;) {

        if (sig_exit) {
            break;
        }

        atun_select_process_events(1500);

        atun_process_posted_event();

        /*
                if (ssl_session.connected == false) {
                    for (auto it = connections.begin(); it != connections.end(); ++it) {
                        auto fd_state = it->second;
                        if (fd_state.first != ssl_session.fd) {
                            close_sock(fd_state.first);
                        }
                    }
                    connections.clear();
                    connections[1] = std::make_pair(ssl_session.fd,true);
                }

                maxfd = add_valid_socket(connections, rset);


                if (ssl_session.connected) {
                    add_valid_socket(connections, maxfd, rset);
                } else {
                    //clean_up(&ssl_session);
                    FD_ZERO(&rset);
                    maxfd = ssl_session.fd;
                    FD_SET(maxfd, &rset);
                }

                struct timeval tv = {1000, 0};
                int ret = select(maxfd + 1, &rset, nullptr, nullptr, &tv);
                if (ret == 0) {
                    std::cout << "timeout\n";
                } else if (ret < 0 ) {
                    std::cout << "select ERR: " << strerror(errno) << "\n";
                } else {
                    event_process(rset, connections, ssl_session);
                }
        */
    }
    
    atun_free();
    
    //clean_up(ssl_session);

    return 0;
}

/*
int event_process(fd_set& rset, uid2fd_map_t &conns, ssl_session_t& ssl_session)
{
     for (auto it = conns.begin(); it != conns.end(); ++it) {
         auto fd_state = it->second;
         if (fd_state.second == false) {
             continue;
         }

         if (FD_ISSET(fd_state.first, &rset)) {
             if (fd_state.first == ssl_session.fd) {
                 handle_ssl_accept_event(conns, ssl_session);
             } else if (fd_state.first == ssl_session.client) {
                 handle_read_ssl_client(conns, ssl_session);
             } else {
                 handle_upstream_read(fd_state.first, ssl_session);
             }
         }
    }

    return 0;
}

int handle_ssl_accept_event(uid2fd_map_t &conns, ssl_session_t& ssl_session)
{
    if (!ssl_session.connected) {

        if (ssl_session.client > 0) {
            // cleanup previously claimed resources
            clean_up_ssl(ssl_session);
        }

        handle_ssl_accept_client(ssl_session);
        conns[2] = std::make_pair(ssl_session.client, true);

    } else {
        // only one
        int fd = accept(ssl_session.fd, nullptr, 0);
        if (fd > 0) {
            close(fd);
        }
    }

    return 0;
}

int handle_read_ssl_client(uid2fd_map_t &conns, ssl_session_t& ssl_session)
{
    return handle_ssl_read(ssl_session);
}
*/
