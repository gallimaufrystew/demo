/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   atun_event.h
 * Author: 19020107
 *
 * Created on April 29, 2018, 4:25 PM
 */

#ifndef ATUN_EVENT_H
#define ATUN_EVENT_H

typedef void (*atun_event_handler)(atun_event& ev);

//using atun_event_handler = std::function<void(atun_event& ev)>;

class atun_event {
    
public:
    
    atun_event(atun_connection& connection) 
    : connection_(connection) {
    }
    
    atun_connection& get_connection() const {
        return connection_;
    }
    
    void set_handler(atun_event_handler handler) {
        handler_ = handler;
    }
    
private:
    
    c handler_;
    
    bool write;
    bool accept;
    bool active;
    bool ready;
    atun_uint_t index;
    atun_connection& connection_;
};

#endif /* ATUN_EVENT_H */
