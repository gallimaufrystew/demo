/*
 * File:   tun_socket.h
 * Author: xinkanhu
 *
 * Created on April 11, 2018
 */

#ifndef TUN_SOCKET_INCLUDED_H
#define TUN_SOCKET_INCLUDED_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <errno.h>
#include <cstdio>
#include <iostream>

typedef int atun_socket_t;

class atun_listen {

    atun_listen() : backlog(5) {
    }

    atun_socket_t open(uint32_t port) {
        //int fd;
        struct sockaddr_in addr = {};

        //memset(&addr, 0, sizeof(struct sockaddr_in));
        addr.sin_family = AF_INET;
        addr.sin_port = htons(port);
        addr.sin_addr.s_addr = htonl(INADDR_ANY);

        fd = socket(AF_INET, SOCK_STREAM, 0);
        if (fd < 0) {
            std::printf("socket() ERR");
            //exit(EXIT_FAILURE);
        }

        int on = 1;
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (const void *) &on, sizeof (int));

        if (bind(fd, (struct sockaddr *) &addr, sizeof (addr)) < 0) {
            std::printf("bind() ERR");
            //exit(EXIT_FAILURE);
        }

        if (listen(fd, backlog) < 0) {
            std::printf("listen() ERR");
            //exit(EXIT_FAILURE);
        }
        return fd;
    }
private:
    atun_socket_t fd;
    struct sockaddr addr;
    socklen_t socklen; /* size of sockaddr */
    size_t addr_text_max_len;
    std::string addr_text;
    int backlog;
    int rcvbuf;
    int sndbuf;
};

class atun_connection {

    atun_connection() {
    }

    atun_socket_t get_sock() const {
        return fd;
    }
    
    atun_ssl& get_ssl() const {
        return ssl_;
    }

private:
    
    atun_ssl& ssl_;
    atun_socket_t fd;
    atun_event read;
    atun_event write;
};

int close_sock(int fd);
int socket_nonblock(int fd);
int socket_block(int fd);
int timeout_connect(int fd, struct sockaddr* addr, socklen_t sock_len);

#endif /* TUN_SOCKET_INCLUDED_H */
