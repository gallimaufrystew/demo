/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   atun_os.h
 * Author: 19020107
 *
 * Created on April 29, 2018, 4:38 PM
 */

#ifndef ATUN_OS_H
#define ATUN_OS_H

#if _WIN32

typedef ssize_t(*atun_recv_pt)(atun_connection_t *c, u_char *buf, size_t size);
typedef ssize_t(*atun_send_pt)(atun_connection_t *c, u_char *buf, size_t size);

class atun_win {

    atun_win() {
        if (WSAStartup(MAKEWORD(2, 2), &ws_ver)) {
            fprintf(stderr, "WSAStartup() fail: %d\n", GetLastError());
            //return -1;
        }
    }

    ~atun_win() {
        WSACleanup();
    }
private:
    WSADATA ws_ver;
};

#endif

#endif /* ATUN_OS_H */
