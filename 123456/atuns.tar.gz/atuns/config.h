
///
/// simple configuration
///

#ifndef CONFIG_H_INCLUDED
#define CONFIG_H_INCLUDED

#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <unordered_map>

typedef std::unordered_map<int, std::pair<std::string, int>> port_map_t;

int init_port_mapping();

#endif
