/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

#include <c++/7/bits/stl_queue.h>


/*
 * Copyright (C) Igor Sysoev
 * Copyright (C) Nginx, Inc.
 */

std::queue<atun_event_t*>  atun_posted_accept_events;
std::queue<atun_event_t*>  atun_posted_events;


void
atun_process_posted_event(std::queue<atun_event_t*> queue)
{
    while (!queue.empty()) {

        atun_event_t *ev = queue.front();

        queue.pop();

        ev->handler(ev);
    }
}
