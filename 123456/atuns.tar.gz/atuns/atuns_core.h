///
/// help.h
///

#if (0)

#ifndef TUNS_CORE_INCLUDED_H_
#define TUNS_CORE_INCLUDED_H_

#include "atun_socket.h"


/*
typedef std::unordered_map<int, std::pair<int, bool>> uid2fd_map_t;
typedef std::unordered_map<int, int> fd2uid_map_t;

int add_valid_socket(uid2fd_map_t &conns, fd_set &rset);
int open_socket(int port);
int open_upstream(int port);
int init_libssl();
void clean_up(ssl_session_t &ssls);
void clean_up_ssl(ssl_session_t &ssls);
int init_ssl_service();
SSL_CTX *create_ssl_ctx(const char *sign_algo);
int create_ssl_context(ssl_session_t &session);
int handle_ssl_accept_client(ssl_session_t &session);
int handle_ssl_read(ssl_session_t &session);
int handle_upstream_read(int fd, ssl_session_t &session);
*/

#endif /* TUNS_CORE_INCLUDED_H_ */
#endif
