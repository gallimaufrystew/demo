
#include "atun_ssl.h"

static int ana_ext_callback(SSL *ssl, unsigned int ext_type,
        const unsigned char *in, size_t inlen, int *al, void *arg);

static SSL_CTX *create_context(const char *sign_algo);

static int atun_ssl_verify(atun_event_t *ev);

static int atun_connect_backend(atun_event_t *ev, int suid, int port);
static bool connection_exists(int suid);

int atun_ssl_write(atun_event_t *ev);
int atun_ssl_greed_read(atun_event_t *ev);
static void atun_ssl_clear_error();
static atun_int_t check_ssl_status(SSL *ssl, int n);
static void atun_add_upstream_write_event(atun_connection_t *c);

int async_connect_by_hostname(std::string &host, int port);

static const char *passwd = "123456", *rfb_command = "RFB_OPEN";
static const int rfb_listen_port = 5900;

static ssl_session_t *ssl_session;

extern port_map_t port_map;

atun_buf_queue up_bufs;

atun_buf_list ssl_write_list, ssl_read_list;
atun_connection all_conns;

void atun_init_ssl_lib()
{
    SSL_library_init();
    SSL_load_error_strings();
}

void atun_free_ssl_data()
{
    SSL_shutdown(ssl_session->ssl);
    SSL_CTX_free(ssl_session->old_ctx);
    SSL_CTX_free(ssl_session->new_ctx);
    SSL_free(ssl_session->ssl);
}

void atun_cleanup_one(atun_buf_list& one)
{
    for (auto it = one.begin(); it != one.end(); ++it) {
        atun_alloc_free(it->first);
    }
    one.clear();
}

void atun_cleanup_queue()
{
    for (auto it = up_bufs.begin(); it != up_bufs.end(); ++it) {
        atun_cleanup_one(it->second);
    }
    up_bufs.clear();
}

void atun_del_all_event()
{
    for (auto it = all_conns.begin(); it != all_conns.end(); ++it) {
        atun_del_conn(it->second.first, 0);
        atun_close_sock(it->second.first->fd);
    }
}

void atun_cleanup_ssl()
{
    atun_del_all_event();
    
    // cleanup all buffered data
    atun_cleanup_queue();
    
    atun_cleanup_event_queue();
    
    // cleanup ssl library structure
    atun_free_ssl_data();
    
    // reclaim all connections
    atun_free_all_conns();
    
    atun_free_ssl_conn();
    
    atun_close_sock(ssl_session->fd);

    // free my allocation
    atun_alloc_free(ssl_session);
    ssl_session = nullptr;
}

int atun_init_ssl_session(atun_int_t fd)
{
    if (ssl_session) {
        atun_cleanup_ssl();
    }
    auto size = sizeof(ssl_session_t);
    ssl_session = static_cast<ssl_session_t *>(atun_alloc(size));
    if (!ssl_session) {
        // fatal...
        return ATUN_ERROR;
    }
    ssl_session->verify_peer = false;
    ssl_session->fd = fd;
    ssl_session->new_ctx = create_context("sha2");
    ssl_session->old_ctx = create_context("sha2");
    ssl_session->ssl = SSL_new(ssl_session->old_ctx);
    if (!ssl_session->ssl) {
        // fatal...
        return ATUN_ERROR;
    }

    SSL_set_accept_state(ssl_session->ssl);

    return ATUN_OK;
}

int atun_ssl_handshake(atun_event_t *ev)
{
    atun_connection_t *c = static_cast<atun_connection_t *>(ev->data);

    atun_ssl_clear_error();
    
    SSL_set_fd(ssl_session->ssl, ssl_session->fd);

    int n = SSL_do_handshake(ssl_session->ssl);
    if (n <= 0) {
        int err = SSL_get_error(ssl_session->ssl, n);
        if (err == SSL_ERROR_WANT_READ || err == SSL_ERROR_WANT_WRITE) {
            return ATUN_OK;
        }
        
        ERR_print_errors_fp(stderr);
        
        atun_cleanup_ssl();
        
        return ATUN_ERROR;
    }

    ev->handler = atun_ssl_verify;

    return ATUN_OK;
}

int atun_verify_peer()
{
    if (!ssl_session->verify_peer) {
        return ATUN_OK;
    }
    
    X509 *cert = SSL_get_peer_certificate(ssl_session->ssl);
    if (!cert) {
        std::cout << "no peer certificate" << "\n";
        return ATUN_ERROR;
    }
    
    long ret = SSL_get_verify_result(ssl_session->ssl);
    if (ret != X509_V_OK) {
        ERR_print_errors_fp(stderr);
        X509_free(cert);
        return ATUN_ERROR;
    }
    
    X509_free(cert);

    return ATUN_OK;
}

int atun_ssl_verify(atun_event_t *ev)
{
    atun_connection_t *c = static_cast<atun_connection_t *>(ev->data);

    int ret = atun_verify_peer();
    if (ret != 0) {
        atun_cleanup_ssl();
    }
    
    ev->handler = atun_ssl_greed_read;

    return ATUN_OK;
}

static void
atun_ssl_clear_error()
{
#if (0)
    while (ERR_peek_error()) {
    }
#endif
    ERR_clear_error();
}

ssize_t atun_ssl_read(char *buf, size_t size)
{
    ssize_t  n, bytes;

    bytes = 0;

    atun_ssl_clear_error();

    /*
     * SSL_read() may return data in parts, so try to read
     * until SSL_read() would return no data
     */

    for (;;) {

        n = SSL_read(ssl_session->ssl, buf, size);
        if (n > 0) {
            bytes += n;
        }

        int ret = check_ssl_status(ssl_session->ssl, n);
        if (ret == ATUN_OK) {
            
            size -= n;
            
            if (size == 0) {
                return bytes;
            }

            buf += n;

            continue;
        }

        if (bytes) {
            return bytes;
        }

        switch (ret) {
        case ATUN_DONE:
        case ATUN_ERROR:
            return ATUN_ERROR;
        case ATUN_AGAIN:
            return ATUN_AGAIN;
        }
    }
}

int unpack_ssl_buf(atun_connection_t *c, atun_event_t *ev,
                  u_char *ssl_data, size_t all_size)
{
    ssize_t  consumed = 0;

next_:

    if (all_size <= PROTO_SIZE) {
        return consumed;
    }

    int len, nlen;
    memcpy(&nlen, ssl_data, 4);
    len = ntohl(nlen);

    int  port, nport;
    memcpy(&nport, ssl_data + 4, 4);
    port = ntohl(nport);

    int  suid, nsuid;
    memcpy(&nsuid, ssl_data + 8, 4);
    suid = ntohl(nsuid);

    //std::cout << "nlen " << nlen << " len " << len << "\n";
    //std::cout << "nport " << nport << " port " << port << "\n";
    //std::cout << "nsuid " << nsuid << " suid " << suid << "\n";

    if (all_size - PROTO_SIZE < len) {
        return consumed;
    }

    if (!connection_exists(suid)) {

        int ret = atun_connect_backend(ev, suid, port);
        if (ret <= 0) {
            // drop
            return ATUN_ERROR;
        }

        init_up_connection(c, ret, suid);

        atun_buf_list null;
        up_bufs[suid] = null;

        auto host = port_map[port];

        if (host.second == rfb_listen_port) {

            consumed += (PROTO_SIZE + len);
            ssl_data += (PROTO_SIZE + len);
            all_size -= (PROTO_SIZE + len);

            goto next_;
        }
    }

#if (111111111111)

    auto uc = all_conns[suid].first;
    all_conns[suid] = std::make_pair(uc, time(NULL));
    
    // still alive?
    
    //std::cout << "up...........uid..." << suid << "\n";
    
    if (!uc->eof) {
        
        u_char *up_data = (u_char *)atun_alloc(len);
        std::memcpy(up_data, ssl_data + PROTO_SIZE, len);
 
        //std::cout << "up...........uid..." << suid << "\n";
        size_t up_size = len;
        up_bufs[suid].push_back(std::make_pair(up_data, up_size));

        atun_add_upstream_write_event(uc);
    }

#endif
    
    consumed += (PROTO_SIZE + len);
    ssl_data += (PROTO_SIZE + len);
    all_size -= (PROTO_SIZE + len);

    goto next_;
}

static
void atun_add_upstream_write_event(atun_connection_t *c)
{
#if (0)
    atun_connection_t *uc = c->peer;
    if (uc == nullptr) {
        std::cout << "atun_add_upstream_write_event what ... " << "\n";
        return;
    }
#endif
    
    if (c->eof) {
        std::cout << "broken connection...." << c << "\n";
        return;
    }
    
    if (!c->write_event->active) {
        c->write_event->handler = atun_upstream_write;
        c->write_event->write = 1;
        atun_add_event(c->write_event, ATUN_WRITE_EVENT, 0);
    }
}

int atun_ssl_greed_read(atun_event_t *ev)
{
    atun_connection_t *c = static_cast<atun_connection_t*>(ev->data);

#define SSL_SIZE 20480

    char ssl_buf[SSL_SIZE] = {};
    ssize_t size = SSL_SIZE;

    ssize_t n = atun_ssl_read(ssl_buf, size);

    //std::cout << "atun_ssl_read -> " << n << "\n";

    if (n <= 0) {
        if (n == ATUN_AGAIN) {
            return ATUN_OK;
        }
        atun_cleanup_ssl();
        return ATUN_ERROR;
    }

#if (111111111)
    
    u_char *save = (u_char*)atun_alloc(n);
    memcpy(save, ssl_buf, n);
    ssl_read_list.push_back(std::make_pair(save, n));

    ssize_t all_size = 0;

    for (auto it = ssl_read_list.begin(); it != ssl_read_list.end(); ++it) {
        all_size += it->second;
    }

    //std::cout << "all_size ... " << all_size << "\n";

    if (all_size <= PROTO_SIZE) {
        return ATUN_OK;
    }

    //std::cout << "11 ... " << all_size << "\n";
    
    u_char *ssl_data = (u_char *)atun_alloc(all_size), *osave = ssl_data;

    for (auto it = ssl_read_list.begin(); it != ssl_read_list.end(); ++it) {
        memcpy(ssl_data, it->first, it->second);
        ssl_data += it->second;
        atun_alloc_free(it->first);
    }

    //std::cout << "22 ... " << all_size << "\n";
    
    ssl_read_list.clear();

    ssl_data = osave;

    int consumed = unpack_ssl_buf(c, ev, ssl_data, all_size);
    
    //std::cout << "consumed ... " << consumed << "\n";
    
    if (consumed > 0) {

        int left_size = all_size - consumed;
        
        if (left_size > 0) {
            u_char *left = (u_char *)atun_alloc(left_size);
            memcpy(left, ssl_data + consumed, left_size);
            ssl_read_list.push_front(std::make_pair(left, left_size));
        }
        
        atun_alloc_free(ssl_data);

        return ATUN_OK;
    }
    
    //std::cout << "111 ... " << consumed << "\n";

    ssl_read_list.push_front(std::make_pair(ssl_data, all_size));

    return ATUN_OK;
    
#endif

}

static bool connection_exists(int suid)
{
    auto it = up_bufs.find(suid);
    if (it == std::end(up_bufs)) {
        return false;
    }
    return true;
}

static atun_int_t
check_ssl_status(SSL *ssl, int n)
{
    int         sslerr;
    atun_err_t  err;

    if (n > 0) {
        return ATUN_OK;
    }

    sslerr = SSL_get_error(ssl, n);

    err = (sslerr == SSL_ERROR_SYSCALL) ? atun_errno : 0;

    if (sslerr == SSL_ERROR_WANT_READ) {
        return ATUN_AGAIN;
    }

    if (sslerr == SSL_ERROR_WANT_WRITE) {
        //std::printf("peer started SSL renegotiation");
        return ATUN_AGAIN;
    }

    if (sslerr == SSL_ERROR_ZERO_RETURN || ERR_peek_error() == 0) {
        std::printf("ssl return zero\n");
        return ATUN_DONE;
    }

    std::printf("SSL_read() err\n");

    return ATUN_ERROR;
}


int atun_ssl_write1(atun_event_t *ev)
{
    atun_connection_t *c = static_cast<atun_connection_t *>(ev->data);

    if (ssl_write_list.empty()) {
        
        atun_del_event(c->write_event, ATUN_WRITE_EVENT, 0);

        return ATUN_OK;
    }

    atun_ssl_clear_error();


    auto item = ssl_write_list.front();
    ssl_write_list.pop_front();
    
    u_char *all = item.first;
    ssize_t all_size = item.second;
    
    std::cout << "ssl write <<<<  " << all_size << "\n";

    auto n = SSL_write(ssl_session->ssl, all, all_size);

    std::cout << "ssl write <<<<<  " << n << "\n";

    if (n > 0) {

        if (n < all_size) {
            int left_size = all_size - n;
            u_char *left = (u_char*)atun_alloc(left_size);
            memcpy(left, all + n, left_size);
            ssl_write_list.push_front(std::make_pair(left, left_size));
        }
        
        if (n == all_size) {
            atun_del_event(c->write_event, ATUN_WRITE_EVENT, 0);
        }

        atun_alloc_free(all);

        return n;
    }
    
    /*

#define SSL_ERROR_NONE               0
#define SSL_ERROR_SSL                1
#define SSL_ERROR_WANT_READ          2
#define SSL_ERROR_WANT_WRITE         3
#define SSL_ERROR_WANT_X509_LOOKUP   4
#define SSL_ERROR_SYSCALL            5
#define SSL_ERROR_ZERO_RETURN        6
#define SSL_ERROR_WANT_CONNECT       7
#define SSL_ERROR_WANT_ACCEPT        8
    
     */

    int sslerr = SSL_get_error(ssl_session->ssl, n);

    int err = (sslerr == SSL_ERROR_SYSCALL) ? errno : 0;

    if (sslerr == SSL_ERROR_WANT_WRITE || sslerr == SSL_ERROR_WANT_READ) {
        
        std::cout << "recoverable..retry.." << "\n";

        //atun_del_event(c->write_event, ATUN_WRITE_EVENT, 0);
        //ssl_write_list.push_front(std::make_pair(all, all_size));

        return ATUN_AGAIN;
    }
    
    std::cout << "SSL_write unrecoverable... " << sslerr << "\n";

    ERR_print_errors_fp(stderr);
            
    // unrecoverable
    atun_cleanup_ssl();

    return ATUN_ERROR;
}


int atun_ssl_write(atun_event_t *ev)
{
    atun_connection_t *c = static_cast<atun_connection_t *>(ev->data);

    if (ssl_write_list.empty()) {
        
        //atun_del_event(c->write_event, ATUN_WRITE_EVENT, 0);

        return ATUN_OK;
    }

    atun_ssl_clear_error();

    ssize_t all_size = 0;
    
    for (auto it = ssl_write_list.begin(); it != ssl_write_list.end(); ++it) {
        all_size += it->second;
    }

    u_char *all = (u_char *)atun_alloc(all_size), *save = all;
    for (auto it = ssl_write_list.begin(); it != ssl_write_list.end(); ++it) {
        memcpy(all, it->first, it->second);
        all += it->second;
        atun_alloc_free(it->first);
    }

    ssl_write_list.clear();

    all = save;
    
    std::cout << "ssl write <<<<  " << all_size << "\n";

    /// retry with exact the same parameters
//retry__:
        
    auto n = SSL_write(ssl_session->ssl, all, all_size);

    std::cout << "ssl write <<<<<  " << n << "\n";

    if (n > 0) {

        if (n < all_size) {
            ssize_t left_size = all_size - n;
            u_char *left = (u_char*)atun_alloc(left_size);
            memcpy(left, all + n, left_size);
            ssl_write_list.push_front(std::make_pair(left, left_size));
        }
        
        if (n == all_size) {
            atun_del_event(c->write_event, ATUN_WRITE_EVENT, 0);
        }

        atun_alloc_free(all);

        return n;
    }
    
    /*

#define SSL_ERROR_NONE               0
#define SSL_ERROR_SSL                1
#define SSL_ERROR_WANT_READ          2
#define SSL_ERROR_WANT_WRITE         3
#define SSL_ERROR_WANT_X509_LOOKUP   4
#define SSL_ERROR_SYSCALL            5
#define SSL_ERROR_ZERO_RETURN        6
#define SSL_ERROR_WANT_CONNECT       7
#define SSL_ERROR_WANT_ACCEPT        8
    
     */

    int sslerr = SSL_get_error(ssl_session->ssl, n);

    int err = (sslerr == SSL_ERROR_SYSCALL) ? errno : 0;

    // retry
    if (sslerr == SSL_ERROR_WANT_WRITE || sslerr == SSL_ERROR_WANT_READ) {
        
        std::cout << "recoverable..retry.." << "\n";
        
        //goto retry__;
        
        //atun_add_event(c->write_event, ATUN_WRITE_EVENT, 0);
        
        //ssl_write_list.push_front(std::make_pair(all, all_size));

        return ATUN_AGAIN;
    }
    
    std::cout << "SSL_write unrecoverable... " << sslerr << "\n";

    ERR_print_errors_fp(stderr);
            
    // unrecoverable
    atun_cleanup_ssl();

    return ATUN_ERROR;
}

int init_up_connection(atun_connection_t *c, atun_int_t fd, int suid)
{
    atun_connection_t *uc = get_connection();
    if (uc == nullptr) {
        // fatal...should not happen
        return ATUN_ERROR;
    }
    
    atun_set_nonblock(fd);

    uc->fd = fd;
    atun_event_t *rev = uc->read_event;

    uc->suid = suid;
    
    c->peer = uc;
    uc->peer = c;

    rev->index = ATUN_INVALID_INDEX;
    rev->write = 0;
    rev->handler = atun_upstream_read;

    atun_add_event(rev, ATUN_READ_EVENT, 0);

#if (0)
    atun_event_t *wev = uc->write_event;
    wev->index = ATUN_INVALID_INDEX;
    wev->write = 1;
    wev->handler = atun_upstream_write;

    atun_select_add_event(wev, ATUN_WRITE_EVENT, 0);
#endif
    
    all_conns[uc->suid] = std::make_pair(uc, time(NULL));

    return 0;
}

int atun_connect_backend(atun_event_t *ev, int suid, int port)
{
    atun_connection_t *c = static_cast<atun_connection_t *>(ev->data);

    auto host = port_map[port];

    sockaddr_in addr = {};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(host.second);

    //std::cout << "backend.... " << host.first << "\n";

    if (valid_ip(host.first, addr)) {

        //std::cout << "connect by ip...\n";

        int sock = socket(AF_INET, SOCK_STREAM, 0);
        if (sock < 0) {
            // possible?
            return ATUN_ERROR;
        }
        
        atun_set_nonblock(sock);
        
        int ret = async_connect(sock, (sockaddr *)&addr, sizeof(addr));
        if (ret <= 0) {
            atun_close_sock(sock);
            return ATUN_ERROR;
        }

        //std::cout << "up fd " << sock << "\n";

        return sock;
    }

    //std::cout << "connect by hostname..." << "\n";
    
    int ret = async_connect_by_hostname(host.first, host.second);
    if (ret <= 0) {
        std::cout << "async_connect_upstream fail" << "\n";
        return ATUN_ERROR;
    }

    return ret;
}

static SSL_CTX *create_context(const char *sign_algo)
{
    SSL_CTX *ctx = nullptr;
    char file_name[512] = {0};

    ctx = SSL_CTX_new(SSLv23_server_method());
    if (!ctx) {
        ERR_print_errors_fp(stderr);
        return nullptr;
    }

    SSL_CTX_set_mode(ctx, SSL_MODE_ENABLE_PARTIAL_WRITE);
    SSL_CTX_set_default_passwd_cb_userdata(ctx, (void *) passwd);
    SSL_CTX_add_server_custom_ext(ctx, CUSTOM_EXT_TYPE_1000,
            nullptr, nullptr, nullptr, ana_ext_callback, ssl_session);

    std::sprintf(file_name, "server_%s.crt", sign_algo);

#if (1)
    //SSL_CTX_use_certificate_chain_file
    if (SSL_CTX_use_certificate_file(ctx, file_name, SSL_FILETYPE_PEM)
            <= 0) {
        //printf("SSL_CTX_use_certificate_file() fail");
        ERR_print_errors_fp(stderr);
        return nullptr;
    }
#else
    X509 *x509 = load_cert(file_name);

    if (SSL_CTX_use_certificate(ssl_ctx, x509) <= 0) {
        //printf("SSL_CTX_use_certificate_file() fail");
        ERR_print_errors_fp(stderr);
        return nullptr;
    }
    X509_free(x509);
#endif

    sprintf(file_name, "server_%s.key", sign_algo);
    if (SSL_CTX_use_PrivateKey_file(ctx, file_name, SSL_FILETYPE_PEM)
            <= 0) {
        //printf("SSL_CTX_use_PrivateKey_file() fail");
        ERR_print_errors_fp(stderr);
        return nullptr;
    }

    if (SSL_CTX_check_private_key(ctx) != 1) {
        //printf("Private and certificate is not matching\n");
        ERR_print_errors_fp(stderr);
        return nullptr;
    }

#if (1)
    SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, nullptr);
    // we can string certs together to form a cert-chain
    sprintf(file_name, "ca_%s.crt", sign_algo);
    if (!SSL_CTX_load_verify_locations(ctx, file_name, nullptr)) {
        ERR_print_errors_fp(stderr);
        return nullptr;
    }
    SSL_CTX_set_verify(ctx, SSL_VERIFY_PEER, nullptr);

    //SSL_CTX_set_verify_depth(ctx, 1);
    //SSL_CTX_set_tlsext_servername_callback(ctx, svr_name_callback);
#endif

    return ctx;
}

static int ana_ext_callback(SSL *ssl, unsigned int ext_type,
        const unsigned char *in, size_t inlen, int *al, void *arg)
{
    char  ext_buf[2048] = {0};
    char *tag = nullptr;
    char  cust_tag[1024] = {0};

    std::memcpy(ext_buf, in, inlen);

    //printf("---ext parse callback---\n");

    tag = strstr(ext_buf, "sign_algo=");
    if (tag) {
        sprintf(cust_tag, "%s", tag + strlen("sign_algo="));
    }

    printf("---cert tag [%s]----\n", cust_tag);

    ssl_session_t *session = (ssl_session_t *) arg;

    SSL_set_SSL_CTX(ssl, session->new_ctx);

    return 1;
}
