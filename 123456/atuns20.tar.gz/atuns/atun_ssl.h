
/*
 * File:   atun_ssl.h
 * Author: 19020107
 *
 * Created on April 29, 2018, 5:57 PM
 */

#ifndef ATUN_SSL_H_INCLUDED
#define ATUN_SSL_H_INCLUDED

#include <openssl/ssl.h>
#include <openssl/err.h>
#include "atun_event.h"
#include "atun_mem.h"
#include "atun_config.h"
#include "atun_connection.h"

#define CUSTOM_EXT_TYPE_1000 10000

#define PROTO_SIZE   12
#define DATA_SIZE    20480

typedef struct {
    bool           verify_peer;
    bool           connected;
    atun_int_t     fd;
    SSL           *ssl;
    SSL_CTX       *old_ctx;
    SSL_CTX       *new_ctx;
} ssl_session_t;

void atun_init_ssl_lib();
int atun_init_ssl_session(atun_int_t fd);
int atun_ssl_handshake(atun_event_t *ev);
int atun_ssl_write(atun_event_t *ev);
int init_up_connection(atun_connection_t *c, atun_int_t fd, int suid);
void atun_cleanup_one(atun_buf_list& one);

#endif /* ATUN_SSL_H_INCLUDED */
