
/*
 * File:   atun_select.h
 * Author: 19020107
 *
 * Created on April 29, 2018, 4:19 PM
 */

#ifndef ATUN_SELECT_H
#define ATUN_SELECT_H

#include "atun_err.h"
#include "atun_config.h"
#include "atun_event.h"
#include "atun_socket.h"

#define ATUN_TIMER_INFINITE  (atun_int_t) -1

#if (0)
atun_int_t atun_select_init();
atun_int_t atun_select_add_event(atun_event_t *ev,
                                 atun_uint_t event, atun_uint_t flags);
atun_int_t atun_select_del_event(atun_event_t *ev,
                                 atun_int_t event, atun_uint_t flags);
uint32_t atun_select_process_events(atun_uint_t timer);

#else

atun_int_t atun_epoll_init();
atun_int_t atun_epoll_add_event(atun_event_t *ev,
                                 atun_uint_t event, atun_uint_t flags);
atun_int_t atun_epoll_del_event(atun_event_t *ev,
                                 atun_int_t event, atun_uint_t flags);
uint32_t atun_epoll_process_events(atun_uint_t timer);
atun_int_t atun_epoll_del_connection(atun_connection_t *c, atun_uint_t flags);

#define atun_del_connection atun_epoll_del_connection
#define atun_event_process_init atun_epoll_init
#define atun_add_event atun_epoll_add_event
#define atun_del_event atun_epoll_del_event
#define atun_process_events atun_epoll_process_events

#endif

#endif /* ATUN_SELECT_H */
