/*
 * File:   tun_socket.h
 * Author: xinkanhu
 *
 * Created on April 11, 2018
 */

#ifndef TUN_SOCKET_INCLUDED_H
#define TUN_SOCKET_INCLUDED_H

#include "atun_config.h"

typedef int atun_socket_t;

int atun_close_sock(int fd);
int atun_set_nonblock(int fd);
int atun_set_block(int fd);
int atun_init_listen_socket();
int async_connect(std::string &host, int port);
int valid_ip(const std::string &host, sockaddr_in &sa);
int async_connect(int fd, sockaddr *addr, socklen_t sock_len);

#endif /* TUN_SOCKET_INCLUDED_H */
