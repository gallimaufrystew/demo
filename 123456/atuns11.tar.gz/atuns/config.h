
///
/// simple configuration
///

#ifndef CONFIG_H_INCLUDED
#define CONFIG_H_INCLUDED

#include "atun_config.h"

typedef std::unordered_map<int, std::pair<std::string, int>> port_map_t;

int init_config();

#endif
