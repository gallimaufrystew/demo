
#include "config.h"

port_map_t port_map;

int init_config()
{
    std::ifstream ifs("tuns.conf");
    std::string line;

    if (!ifs.is_open()) {
        std::cout << "configuration file doesn't exist\n";
        exit(-1);
    }

    while (std::getline(ifs, line)) {
        std::string key, first, second;
        std::istringstream is(line);
        is >> key >> first >> second;
        if (!key.empty()) {
            if (key[0] == '#') {
                continue;
            }
            port_map[std::atoi(key.c_str())] =
                std::make_pair(first, std::atoi(second.c_str()));
        }
    }
    ifs.close();

    return 0;
}
