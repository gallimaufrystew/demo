
/*
 * File:   atun_event.h
 * Author: 19020107
 *
 * Created on April 29, 2018, 4:25 PM
 */

#ifndef ATUN_EVENT_H
#define ATUN_EVENT_H

#include "atun_config.h"
#include "atun_socket.h"

#define ATUN_INVALID_INDEX  0xd0d0d0d0

#if (0)

#define ATUN_READ_EVENT     0
#define ATUN_WRITE_EVENT    1

#else

#define ATUN_CLOSE_EVENT     1
#define ATUN_READ_EVENT      (EPOLLIN|EPOLLRDHUP)
#define ATUN_WRITE_EVENT     EPOLLOUT

#endif

#define MAX_CONNECTIONS  32

typedef struct atun_event_s atun_event_t;
typedef struct atun_connection_s atun_connection_t;
typedef int (*atun_event_handler)(atun_event_t *ev);
typedef std::queue<atun_event_t *> event_queue;

//typedef std::deque<std::pair<u_char *, int>> data_queue;
//typedef std::unordered_map<int, atun_connection_t*> up_lnk_map;

typedef std::list<std::pair<u_char *, int>> stream_queue;
typedef std::unordered_map<int, stream_queue> up_lnk_queue_map;
typedef std::unordered_map<int, std::pair<atun_connection_t*, time_t>> conn_time_out;

struct atun_connection_s {
    atun_socket_t        fd;
    atun_event_t        *read_event;
    atun_event_t        *write_event;
    atun_int_t           suid, port;
    atun_connection_t   *peer;
};

struct atun_event_s {
    void               *data;
    unsigned            write: 1;
    unsigned            accept: 1;
    unsigned          active: 1;
    unsigned          ready: 1;
    unsigned          instance: 1;
    atun_uint_t         index;
    atun_event_handler  handler;
};

void atun_process_posted_event();
void atun_post_event(atun_event_t *ev);

#endif /* ATUN_EVENT_H */
