
#include "atun_connection.h"
#include "atun_ssl.h"
#include "atun_config.h"

static connection_list connections;

extern port_map_t port_map;
extern atun_buf_queue up_bufs;
extern atun_connection all_conns;
extern atun_buf_list ssl_write_list, ssl_read_list;

static atun_connection_t *atun_ls_conn, *atun_ssl_conn;

int atun_accept(int s)
{
    int fd;
    
    while (1) {
        fd = accept(s, nullptr, 0);
        if (fd == -1) {
            if (errno == EINTR)
                continue;
            else {
                // fatal...
                return ATUN_ERROR;
            }
        }
        break;
    }
    return fd;
}

int atun_add_listen_read_event(int ls)
{
    atun_set_nonblock(ls);

    atun_ls_conn = get_connection();
    if (atun_ls_conn == nullptr) {
        // fatal...
        return ATUN_ERROR;
    }

    atun_ls_conn->fd = ls;
    atun_ls_conn->read_event->accept = 1;
    atun_ls_conn->read_event->write = 0;
    atun_ls_conn->read_event->handler = atun_event_accept;

    atun_add_event(atun_ls_conn->read_event, ATUN_READ_EVENT, 0);
    
    return ATUN_OK;
}

void atun_free_ls_conn()
{
    if (atun_ls_conn) {
        atun_free_connection(atun_ls_conn);
    }    
}

void atun_free_ssl_conn()
{
    if (atun_ssl_conn) {
        atun_free_connection(atun_ssl_conn);
    }
}

int atun_add_tunnel_event(int ss)
{
    atun_ssl_conn = get_connection();
    if (atun_ssl_conn == nullptr) {
        // fatal...
        return ATUN_ERROR;
    }
    
    atun_ssl_conn->fd = ss;
    atun_ssl_conn->read_event->accept = 0;
    atun_ssl_conn->read_event->write = 0;
    atun_ssl_conn->read_event->handler = atun_ssl_handshake;

    atun_add_event(atun_ssl_conn->read_event, ATUN_READ_EVENT, 0);
    
    return 0;
}

int atun_event_accept(atun_event_t *ev)
{
    atun_connection_t *c = static_cast<atun_connection_t *>(ev->data);
    int fd = atun_accept(c->fd);
    if (fd <= 0) {
        return ATUN_ERROR;
    }

    std::cout << "ssl fd " << fd << "\n";

    atun_set_nonblock(fd);

    int ret = atun_init_ssl_session(fd);
    if (ret != 0) {
        return ATUN_ERROR;
    }
    
    atun_add_tunnel_event(fd);

    return ATUN_OK;
}

void atun_check_timeout()
{
    time_t current = time(NULL);
    
    for (auto it = all_conns.begin(); it != all_conns.end(); ++it) {
        auto uc = it->second;
        if (current - uc.second >= 20) {
            uc.first->eof = 1;
        }
    }
}

atun_connection_t *get_connection()
{
    atun_connection_t *c = nullptr;

    if (connections.empty()) {
        return c;
    }

    c = connections.front();
    connections.pop_front();

    c->read_event->instance = 1;
    c->read_event->index = ATUN_INVALID_INDEX;
    
    c->write_event->instance = 1;
    c->write_event->index = ATUN_INVALID_INDEX;
        
    c->eof = 0;
    c->peer = nullptr;

#if (0)
    atun_event_t *rev = c->read_event;
    rev->instance = !rev->instance;
    
    atun_event_t *wev = c->write_event;
    wev->instance = !wev->instance;
    
    memset(c,0,sizeof(atun_connection_t));
    
    c->read_event = rev;
    c->write_event = wev;
#endif
    
    return c;
}

void atun_free_all_conns()
{
    for (auto it = all_conns.begin(); it != all_conns.end(); ++it) {
        atun_free_connection(it->second.first);
    }
    all_conns.clear();
}

void atun_free_connection(atun_connection_t *c)
{
    connections.push_back(c);
}

void atun_init_connection(int max_connection)
{
    size_t conn_size = sizeof(atun_connection_t);
    size_t event_size = sizeof(atun_event_t);

    for (int i = 0; i < max_connection; ++i) {
        atun_connection_t *c =
            static_cast<atun_connection_t *>(atun_alloc(conn_size));
        if (c == nullptr) {
            // fatal...
            return;
        }
        
        std::cout << "allocate connection..." << c << "\n";

        c->read_event =
            static_cast<atun_event_t *>(atun_alloc(event_size));
        if (c->read_event == nullptr) {
            // fatal...
            return;
        }
        c->read_event->data = c;
        c->read_event->instance = 1;
        c->read_event->index = ATUN_INVALID_INDEX;

        c->write_event =
            static_cast<atun_event_t *>(atun_alloc(event_size));
        if (c->write_event == nullptr) {
            // fatal...
            return;
        }
        c->write_event->data = c;
        c->write_event->instance = 1;
        c->write_event->index = ATUN_INVALID_INDEX;
        connections.push_back(c);
    }
}

void atun_finalize_connection(atun_connection_t *c)
{
    std::cout << "finalize..." << "\n";
    
    // free connection > when...
    c->eof = 1;
    
    atun_del_conn(c, 0);
    
    atun_close_sock(c->fd);
    
    for (auto it = up_bufs[c->suid].begin(); it != up_bufs[c->suid].end(); ++it) {
        atun_alloc_free(it->first);
    }
    up_bufs[c->suid].clear();
}

void atun_add_ssl_write_event(atun_connection_t *uc)
{
    atun_connection_t *peer = uc->peer;
    if (!peer->write_event->active) {
        peer->write_event->handler = atun_ssl_write;
        peer->write_event->write = 1;
        atun_add_event(peer->write_event, ATUN_WRITE_EVENT, 0);
    }
}

int atun_upstream_read(atun_event_t *ev)
{
    atun_connection_t *uc = static_cast<atun_connection_t *>(ev->data);

    ssize_t  n;

    u_char buf[DATA_SIZE] = {};

    //std::cout << "read from..........." << uc->fd << "\n";
            
    //do {
        n = recv(uc->fd, buf + PROTO_SIZE, DATA_SIZE - PROTO_SIZE, 0);

        if (n > 0) {

            std::cout << " upstream size <- " << n << "\n";

            int  nlen;
            nlen = htonl(n);
            memcpy(buf, &nlen, 4);
            
            ////////////////////////////////
            
            int nsuid;
            nsuid = htonl(uc->suid);
            memcpy(buf + 8, &nsuid, 4);

            size_t size = n + PROTO_SIZE;

            u_char *data = (u_char *)atun_alloc(size);
            std::memcpy(data, buf, size);
            ssl_write_list.push_back(std::make_pair(data, size));
            
            atun_add_ssl_write_event(uc);

            return n;
        }
        
        if (errno == EAGAIN || errno == EINTR) {
            
            // possible>?

            return ATUN_AGAIN;
        }

        //if (n == 0) {
            //close(uc->fd);
        //    return n;
        //}

        //if (errno == EAGAIN || errno == EINTR) {
            // can retry
            //n = ATUN_AGAIN;
        //} else {
            // unrecoverable error
        //    break;
        //}

    //} while (errno == EINTR);
        
        atun_finalize_connection(uc);

    return n;

#if (0)
    int n = recv(uc->fd, buf + PROTO_SIZE, DATA_SIZE - PROTO_SIZE, 0);
    if (n <= 0) {
        if (errno == EINTR || errno == EWOULDBLOCK || errno == EAGAIN) {
            return 0;
        }

        std::cout <<  __func__ << " fatal " << errno << "\n";

        atun_select_del_event(uc->read_event, ATUN_READ_EVENT, 0);
        atun_free_connection(uc);

        return -1;
    }
#endif

}

int atun_upstream_write(atun_event_t *ev)
{
    atun_connection_t *c = static_cast<atun_connection_t *>(ev->data);

    if (up_bufs[c->suid].empty()) {

        return ATUN_OK;
    }

    ssize_t all_size = 0;

    for (auto it = up_bufs[c->suid].begin(); it != up_bufs[c->suid].end(); ++it) {
        all_size += it->second;
    }

    u_char *all = (u_char *)atun_alloc(all_size), *osave = all;
    for (auto it = up_bufs[c->suid].begin(); it != up_bufs[c->suid].end(); ++it) {
        memcpy(all, it->first, it->second);
        all += it->second;
        atun_alloc_free(it->first);
    }

    all = osave;
    up_bufs[c->suid].clear();

    int up_fd = c->fd;//all_conns[c->suid].first->fd;

    //for ( ;; ) {

    ssize_t n = send(up_fd, all, all_size, 0);
    if (n > 0) {

        std::cout << "up write " << all_size << " -->> " << n << "\n";

        //all += n;
        //all_size -= n;
        
        ssize_t left = all_size - n;

        if (left == 0) {

            atun_del_event(c->write_event, ATUN_WRITE_EVENT, 0);
                    
            atun_alloc_free(all);
            
            return ATUN_OK;
        }

        u_char *remain = (u_char *)atun_alloc(left);
        memcpy(remain, all + n, left);
        up_bufs[c->suid].push_front(std::make_pair(remain, left));

        atun_alloc_free(all);

        return ATUN_OK;
    }
    
    if (errno == EINTR || errno == EAGAIN) {

        size_t left = all_size;
        up_bufs[c->suid].push_front(std::make_pair(all, left));

        return ATUN_AGAIN;
    }
    
    // unrecoverable
    atun_finalize_connection(c);

    return ATUN_ERROR;

    //}

#if (0)
    int n = send(c->fd, item.first, item.second, 0);

    if (n == 0) {
        return n;
    }

    if (n < 0) {
        if (errno == EINTR || errno == EAGAIN) {
            uplnks[c->suid].push_front(item);
            //uplnks[c->suid] = up_queue;
            return 0;
        }

        uplnks[c->suid].push_front(item);
        // todo fatal error
        std::cout <<  __func__ << " send fatal " << strerror(errno) << "\n";
        return -1;
    }

    item.second -= n;
    item.first += n;

    if (item.second == 0) {
        return 0;
        //delete [] opos;
    }

    uplnks[c->suid].push_front(std::make_pair(opos, item.second));
#endif

}
