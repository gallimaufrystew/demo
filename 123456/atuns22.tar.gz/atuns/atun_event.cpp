
#include "atun_event.h"
#include "atun_connection.h"
#include "atun_ssl.h"

atun_event_action_t atun_event_action;

extern atun_event_action_t select_action;
extern atun_event_action_t epoll_action;

static atun_event_queue  atun_posted_events;

extern atun_buf_queue up_bufs;
extern atun_connection all_conns;

void atun_event_process_init()
{
    
#if (USE_EPOLL)
    
    atun_event_action = epoll_action;
    
#elif (USE_KQUEUE)
///////////////////////////////////////
#elif (USE_EVENT_PORT)
///////////////////////////////////////
#else
    atun_event_action = select_action;    
#endif
    
    atun_event_action.init();
}

void atun_cleanup_one_upconn(atun_connection_t *uc)
{
    atun_del_conn(uc, 0); 
    atun_cleanup_one(up_bufs[uc->suid]);
    up_bufs.erase(uc->suid);
    all_conns.erase(uc->suid);
    atun_free_connection(uc);
}

void atun_process_posted_event()
{
    std::set<atun_connection_t*> conns;
    
    while (!atun_posted_events.empty()) {

        atun_event_t *ev = atun_posted_events.front();

        atun_posted_events.pop();
        
        atun_connection_t *c = (atun_connection_t*)ev->data;
        
        if (c->eof) {
            conns.insert(c);
            continue;
        }

        ev->handler(ev);
    }
    
    // cleanup one up connection
    for (auto it = conns.begin(); it != conns.end(); ++it) {
        atun_cleanup_one_upconn(*it);
    }
}

void atun_post_event(atun_event_t *ev)
{
    atun_posted_events.push(ev);
}

void atun_cleanup_event_queue()
{
    std::queue<atun_event_t*> empty;
    std::swap(atun_posted_events, empty);
}
