
///
/// simple configuration
///

#ifndef CONFIG_H_INCLUDED
#define CONFIG_H_INCLUDED

#include "atun_sys_config.h"

typedef std::pair<std::string, int> addr_port;
typedef std::unordered_map<int, addr_port> port_map_t;

int atun_init_config();

#endif
