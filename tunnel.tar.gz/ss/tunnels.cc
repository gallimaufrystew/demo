///
/// File:   tunnels.c
/// Author: xingkanhu
///

#include "help.h"

int event_process(fd_set *fdset, std::vector<int> &fd_vec, ssl_session_t *ssl_session);
int handle_read_ssl_client(std::vector<int> &fd_vec, ssl_session_t *ssl_session);
int handle_ssl_accept_event(std::vector<int> &fd_vec, ssl_session_t *ssl_session);

int main(int argc, char *argv[])
{
    long timeout = 1000;
    int maxfd = -1;
    bool running = true;
    fd_set fdset;
    struct timeval tv;
    struct sigaction sa;

    std::vector<int> fd_vec;

    ssl_session_t ssl_session;
    ssl_session.verify_peer = false;
    ssl_session.connected = false;
    ssl_session.connected_count = 0;

    maxfd = ssl_session.fd = open_ssl(443);

    printf("ssl fd %d\n", ssl_session.fd);

    puts("start handling event...");

    fd_vec.push_back(STDIN_FILENO);
    fd_vec.push_back(ssl_session.fd);

    sa.sa_handler = SIG_IGN;
    sa.sa_flags = 0;

    sigemptyset(&sa.sa_mask);
    sigaction(SIGPIPE, &sa, 0);

    while (running) {

        tv.tv_sec = timeout;
        tv.tv_usec = 0;

        FD_ZERO(&fdset);

        for (int i = 0; i < fd_vec.size(); ++i) {
            maxfd = std::max(maxfd, fd_vec[i]);
            FD_SET(fd_vec[i], &fdset);
        }

        if (select(maxfd + 1, &fdset, nullptr, nullptr, &tv) == 0) {
            //timeoout
        } else {
            event_process(&fdset, fd_vec, &ssl_session);
        }
    }

    SSL_shutdown(ssl_session.ssl);
    SSL_free(ssl_session.ssl);

    SSL_CTX_free(ssl_session.ssl_old_ctx);
    SSL_CTX_free(ssl_session.ssl_new_ctx);

    for (int i = 0; i < fd_vec.size(); ++i) {
        close(fd_vec[i]);
    }

    return 0;
}

int event_process(fd_set *fdset, std::vector<int> &fd_vec, ssl_session_t *ssl_session)
{

    if (FD_ISSET(0, fdset)) {
        puts("key input");
        //getchar();
        //running = false;
    }

    for (int i = 0; i < fd_vec.size(); ++i) {

        if (FD_ISSET(fd_vec[i], fdset)) {

            if (fd_vec[i] == ssl_session->fd) {
                handle_ssl_accept_event(fd_vec, ssl_session);
            } else if (fd_vec[i] == ssl_session->client) {
                handle_read_ssl_client(fd_vec, ssl_session);
            } else {
                handle_upstream_read(fd_vec[i], ssl_session);
            }
        }
    }

    return 0;
}

int handle_ssl_accept_event(std::vector<int> &fd_vec, ssl_session_t *ssl_session)
{
    if (!ssl_session->connected) {
        if (ssl_session->connected_count) {
            // cleanup previously claimed resources
            /*
            SSL_shutdown(ssl_session->ssl);
            SSL_free(ssl_session->ssl);

            SSL_CTX_free(ssl_session->ssl_old_ctx);
            SSL_CTX_free(ssl_session->ssl_new_ctx);
            close(ssl_session->client);
            */
        }

        handle_ssl_accept_client(ssl_session);
        fd_vec.push_back(ssl_session->client);

    } else {
        // only one
        int fd = accept(ssl_session->fd, nullptr, 0);
        if (fd > 0) {
            close(fd);
        }
    }

    return 0;

}

int handle_read_ssl_client(std::vector<int> &fd_vec, ssl_session_t *ssl_session)
{
    int up_fd = handle_ssl_read(ssl_session);
    if (up_fd > 0) {
        fd_vec.push_back(up_fd);
    }

    return 0;
}
