/*
 * tunnelc.cc
 *
 *  Created on: Mar 26, 2018
 *      Author: lfs
 */

#include "help.h"

int event_process(fd_set *fdset, ssl_conn_t *ssl_conn,std::vector<int> &fd_vec, 
                  fd_desc_map &fd_desc_maps,fd_port_map &fd_port_maps);
int handle_client_event(int fd, ssl_conn_t *ssl_conn,fd_desc_map &fd_desc_maps, fd_port_map &fd_port_maps,std::vector<int> &fd_vec);

int main(int argc, char **argv)
{
    long timeout = 1000;
    std::vector<int> ports;
    int maxfd = -1;
    bool running = true;
    fd_set fdset;

    std::vector<int> fd_vec;

    fd_desc_map fd_desc_maps;
    fd_port_map fd_port_maps;

    ssl_conn_t ssl_conn;
    init_ssl_config(&ssl_conn);

    init_config(ports);

    client_open_ssl(&ssl_conn);

    fd_vec.push_back(ssl_conn.fd);

    fd_desc_maps[ssl_conn.fd] = "ssl";

    for (int i = 0; i < ports.size(); ++i) {
        int fd = server_open_socket(ports[i], fd_port_maps);
        fd_vec.push_back(fd);
        fd_desc_maps[fd] = "listen";
    }
    fd_vec.push_back(STDIN_FILENO);

    puts("start handling event...");

    struct timeval tv;

    while (running) {

        FD_ZERO(&fdset);

        for (int i = 0; i < fd_vec.size(); ++i) {
            maxfd = std::max(maxfd, fd_vec[i]);
            FD_SET(fd_vec[i], &fdset);
        }

        tv.tv_sec = timeout;
        tv.tv_usec = 0;

        if (select(maxfd + 1, &fdset, NULL, NULL, &tv) == 0) {
            //printf("%ld elapsed,timeout\n", timeout);
        } else {
            event_process(&fdset, &ssl_conn, fd_vec,fd_desc_maps,fd_port_maps);
        }
    }

    SSL_shutdown(ssl_conn.ssl);
    SSL_free(ssl_conn.ssl);

    SSL_CTX_free(ssl_conn.ssl_ctx);

    for (int i = 0; i < fd_vec.size(); ++i) {
        close(fd_vec[i]);
    }

    return 0;
}

int event_process(fd_set *fdset, ssl_conn_t *ssl_conn,
                  std::vector<int> &fd_vec, fd_desc_map &fd_desc_maps,
                  fd_port_map &fd_port_maps)
{

    if (FD_ISSET(0, fdset)) {
        puts("key input");
        //getchar();
        //running = false;
    }

    for (int i = 0; i < fd_vec.size(); ++i) {

        if (FD_ISSET(fd_vec[i], fdset)) {

            if (fd_vec[i] == ssl_conn->fd) {

                handle_ssl_read(ssl_conn);

            } else {
                
                handle_client_event(fd_vec[i], ssl_conn, fd_desc_maps, fd_port_maps, fd_vec);
            }
        }
    }

    return 0;
}

int handle_client_event(int fd, ssl_conn_t *ssl_conn,
                        fd_desc_map &fd_desc_maps, fd_port_map &fd_port_maps,
                        std::vector<int> &fd_vec)
{

    fd_desc_map::iterator it;
    it = fd_desc_maps.find(fd);

    if (it != fd_desc_maps.end()) {

        if (it->second == "listen") {

            int client = 0;
            client = handle_accept(fd, fd_port_maps);
            if (client > 0) {
                printf("one client [%d],[%d]\n", fd, client);
                fd_desc_maps[client] = "client";
                fd_vec.push_back(client);
            }
        } else {

            int ret = handle_read_client(fd, ssl_conn, fd_port_maps);
            if (it->second != "keep" || ret < 0) {
                //fd_desc_maps[i] = "delete";
            }
        }
    }

    return 0;
}
