///
/// help function
///

#ifndef HELP_INCLUDED_CC_
#define HELP_INCLUDED_CC_

#include "help.h"
#include "config.h"

#define HEAD_SIZE         6
#define MAX_CHUNK_SIZE    81920

const char *passwd = "123456";

std::map<int, int> up_conn_maps, down_conn_maps;
std::map<int, std::pair<std::string, int>> port_maps;

static int ana_ext_callback(SSL *ssl, unsigned int ext_type,
                            const unsigned char *in, size_t inlen, int *al, void *arg);

int loop_write(int fd, void *buffer, int length);
int loop_ssl_write(SSL *ssl, void *buffer, int length);
int loop_ssl_read(SSL *ssl, void *buffer, int length);

#if (0)
static int svr_name_callback(SSL *ssl, int *a, void *b);
static int cert_callback(SSL *ssl, void *a);
static X509 *load_cert(const char *file);
#endif

int loop_write(int fd, void *buffer, int length)
{
    int    bytes_left, written_bytes;
    char  *ptr = static_cast<char*>(buffer);
    
    bytes_left = length;
    
    while (bytes_left > 0) {   
        written_bytes = write(fd, ptr, bytes_left);
        if (written_bytes <= 0) {       
            if(errno == EINTR) {
                written_bytes = 0;
            } else {
                return -1;
            }
        }
        bytes_left -= written_bytes;
        ptr += written_bytes;     
    }
    return 0;
}

int loop_ssl_read(SSL *ssl, void *buffer, int length)
{
    int    bytes_left, bytes_read;
    char  *ptr = static_cast<char*>(buffer);
    
    bytes_left = length;
    
    while (bytes_left > 0) {
        bytes_read = SSL_read(ssl, ptr, bytes_left);
        if (bytes_read <= 0) {
            int err = SSL_get_error(ssl,bytes_read);
            if (err == SSL_ERROR_WANT_READ || err == SSL_ERROR_WANT_WRITE) {
                bytes_read = 0;
            } else {
                return -1;
            }
        }
        bytes_left -= bytes_read;
        ptr += bytes_read;
    }
    return 0;
}

int loop_ssl_write(SSL *ssl, void *buffer, int length)
{
    int    bytes_left, written_bytes;
    char  *ptr = static_cast<char*>(buffer);
    
    bytes_left = length;
    
    while (bytes_left > 0) {
        written_bytes = SSL_write(ssl, ptr, bytes_left);
        if (written_bytes <= 0) {
            int err = SSL_get_error(ssl,written_bytes);
            if (err == SSL_ERROR_WANT_READ || err == SSL_ERROR_WANT_WRITE) {
                written_bytes = 0;
            } else {
                return -1;
            }
        }
        bytes_left -= written_bytes;
        ptr += written_bytes;
    }
    return 0;
}

int handle_ssl_read(ssl_session_t *session)
{
    char buf[HEAD_SIZE + MAX_CHUNK_SIZE] = { 0 };

    int n = loop_ssl_read(session->ssl, buf, HEAD_SIZE);
    if (n != 0) {
        std::cout << "read head err\n";
        session->connected = false;
        return -1;
    }

    if (n != 0) {
        std::cout << "!!!!!!!!!!!!!!!!!! 1 incomplete ssl read --->\n";
    }
    
    uint16_t len,nlen;
    memcpy(&nlen, buf, 2);
    len = ntohs(nlen);

    uint16_t port, nport;
    memcpy(&nport, buf + 2, 2);
    port = ntohs(nport);

    uint16_t fd, nfd;
    memcpy(&nfd, buf + 4, 2);
    fd = ntohs(nfd);

    n = loop_ssl_read(session->ssl, buf + HEAD_SIZE, len);
    if (n != 0) {
        std::cout << "read body err\n";
        session->connected = false;
        return -1;
    }
    
    if (n != 0) {
        std::cout << "!!!!!!!!!!!!!!!!!! 2 incomplete ssl read --->\n";
    }
       
    std::cout << "ssl data size ---> " << len << '\n';

#if (0)
    std::string request(buf + HEAD_SIZE);

    std::string::size_type start = 0,end = -1,count,i = request.find("Host");

    // 512 should be enough
    for (int j = i;j < 512;++j) {
        if (request[j] == ' ' && request[j + 1] != ' ') {
            start = j + 1;
            j ++;
            count = 0;
        }
        if (request[j] == '\r') {
            break;
        }
        count++;
    }

    std::string host = request.substr(start,count-start+1);

    for (int j = 0; j < host.size();++j) {
        if (host[j] == ':') {
            end = j;
        }
    }

    if (end == -1) {
        port_maps[port].first = host;
    } else {
        port_maps[port].first = host.substr(0,end);
    }
    std::cout << "==================remote host===============:" << port_maps[port].first;
    //request.replace(i,count,"Host: www.bbc.com");

    std::cout << "up stream request:" << request;
#endif

    //std::map<int, int>::iterator it;
    auto it = up_conn_maps.find(fd);
    if (it == up_conn_maps.end()) {

        printf("NO connection exist open it [%d][%d]\n", port, port_maps[port].second);

        up_conn_maps[fd] = open_connection(port);
        down_conn_maps[up_conn_maps[fd]] = fd;

        //printf("write to upstream %d %d\n", up_conn_maps[fd], fd);
        n = loop_write(up_conn_maps[fd], buf + HEAD_SIZE, len);
        
        if (n != 0) {
            std::cout << "!!!!!!!!!!!!!!!!!! 1 incomplete write --->\n";
        }
        
        return up_conn_maps[fd];

    } else {
    
        n = loop_write(it->second, buf + HEAD_SIZE, len);
        
        if (n != 0) {
            std::cout << "!!!!!!!!!!!!!!!!!! 2 incomplete write --->\n";
        }
        
        return 0;
    }
}

int handle_upstream_read(int fd, ssl_session_t *session)
{
    char buf[HEAD_SIZE + MAX_CHUNK_SIZE] = { 0 };

    uint16_t len = read(fd, buf + HEAD_SIZE, MAX_CHUNK_SIZE);
    if (len <= 0) {
        return -1;
    }
        
    std::cout << "upstream data size <--- " << len << '\n';

    uint16_t nlen;
    nlen = htons(len);
    memcpy(buf, &nlen, 2);
    
    // now port is of no importance
    // for simplicity we omit it

    uint16_t nfd;
    nfd = htons(down_conn_maps[fd]);
    memcpy(buf + 4, &nfd, 2);

    int n = loop_ssl_write(session->ssl, buf, len + HEAD_SIZE);
    if (n != 0) {
        session->connected = false;
        return -1;
    }
    
    if (n != 0) {
       std::cout << "!!!!!!!!!!!!!!!!!! incomplete ssl write <---\n";
    }
    
    return 0;
}

int open_socket(int port)
{
    int fd;
    struct sockaddr_in addr;

    memset(&addr, 0, sizeof(struct sockaddr_in));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = htonl(INADDR_ANY);/* inet_addr("127.0.0.1") */

    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        perror("socket() failed");
        exit(EXIT_FAILURE);
    }

    int on = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (const void *)&on, sizeof(int));

    if (bind(fd, (struct sockaddr *) &addr, sizeof(addr)) < 0) {
        perror("bind() failed");
        exit(EXIT_FAILURE);
    }

    if (listen(fd, 5) < 0) {
        perror("listen() failed");
        exit(EXIT_FAILURE);
    }

    return fd;
}

static void *fill_in_addr(struct sockaddr *sa)
{
    if (sa->sa_family == AF_INET) {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }

    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

static int connect_by_hostname(std::string& host,int port)
{
    int   fd,rv;
    struct addrinfo hints, *servinfo, *p;
    char  s[INET6_ADDRSTRLEN];

    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_INET;// AF_UNSPEC AF_INET6
    hints.ai_socktype = SOCK_STREAM;

    char service[128] = {0};
    sprintf(service,"%d",port);

    if ((rv = getaddrinfo(host.c_str(), service, &hints, &servinfo)) != 0) {
        fprintf(stderr, "server getaddrinfo: %s\n", gai_strerror(rv));
        return -1;
    }

    for (p = servinfo; p != nullptr; p = p->ai_next) {
        if ((fd = socket(p->ai_family, p->ai_socktype,p->ai_protocol)) == -1) {
            perror("server socket");
            continue;
        }

        if (connect(fd, p->ai_addr, p->ai_addrlen) == -1) {
            perror("server connect");
            close(fd);
            continue;
        }

        break;
    }

    if (p == nullptr) {
        fprintf(stderr, "failed to connect to upstream\n");
        return -1;
    }

    inet_ntop(p->ai_family, fill_in_addr((struct sockaddr *)p->ai_addr),s, sizeof s);
    std::cout << "connection to upstream " << s << "\n";

    freeaddrinfo(servinfo);

    return fd;
}

int open_connection(int port)
{
    return connect_by_hostname(port_maps[port].first,port_maps[port].second);

#if (0)
    int fd;
    struct sockaddr_in addr;

    if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        printf("Error on socket creation\n");
        return -1;
    }

    memset(&addr, 0, sizeof(struct sockaddr_in));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port_maps[port].second);
    addr.sin_addr.s_addr = inet_addr(port_maps[port].first.c_str());

    connect(fd, (struct sockaddr *) &addr, sizeof(struct sockaddr_in));

    return fd;
#endif
}

int init_libssl()
{
    SSL_library_init();
    SSL_load_error_strings();

    init_port_mapping();

#if (0)
    // port mapping
    port_maps[1031] = std::make_pair("shal2057", 5555);
    port_maps[1032] = std::make_pair("shal2057", 6666);
    port_maps[1033] = std::make_pair("shal2057", 80);
#endif

    return 0;
}

int open_ssl(int port)
{

    init_libssl();

    return open_socket(port);
}

SSL_CTX *create_ssl_ctx(const char *sign_algo, ssl_session_t *session)
{
    SSL_CTX *ssl_ctx = nullptr;
    char file_name[512] = { 0 };

    ssl_ctx = SSL_CTX_new(SSLv23_server_method());
    if (!ssl_ctx) {
        ERR_print_errors_fp(stderr);
        return nullptr;
    }

    SSL_CTX_set_default_passwd_cb_userdata(ssl_ctx, (void *)passwd);
    SSL_CTX_add_server_custom_ext(ssl_ctx, CUSTOM_EXT_TYPE_1000, nullptr, nullptr, nullptr, ana_ext_callback, session);

    sprintf(file_name, "server_%s.crt", sign_algo);

#if (1)
    //SSL_CTX_use_certificate_chain_file
    if (SSL_CTX_use_certificate_file(ssl_ctx, file_name, SSL_FILETYPE_PEM)
            <= 0) {
        //printf("SSL_CTX_use_certificate_file() fail");
        ERR_print_errors_fp(stderr);
        return nullptr;
    }
#else
    X509 *x509 = load_cert(file_name);

    if (SSL_CTX_use_certificate(ssl_ctx, x509) <= 0) {
        //printf("SSL_CTX_use_certificate_file() fail");
        ERR_print_errors_fp(stderr);
        return nullptr;
    }
    X509_free(x509);
#endif

    sprintf(file_name, "server_%s.key", sign_algo);
    if (SSL_CTX_use_PrivateKey_file(ssl_ctx, file_name, SSL_FILETYPE_PEM)
            <= 0) {
        //printf("SSL_CTX_use_PrivateKey_file() fail");
        ERR_print_errors_fp(stderr);
        return nullptr;
    }

    if (SSL_CTX_check_private_key(ssl_ctx) != 1) {
        //printf("Private and certificate is not matching\n");
        ERR_print_errors_fp(stderr);
        return nullptr;
    }

#if (1)
    SSL_CTX_set_verify(ssl_ctx, SSL_VERIFY_PEER, nullptr);
    // we can string certs together to form a cert-chain
    sprintf(file_name, "ca_%s.crt", sign_algo);
    if (!SSL_CTX_load_verify_locations(ssl_ctx, file_name, nullptr)) {
        ERR_print_errors_fp(stderr);
        return nullptr;
    }
    SSL_CTX_set_verify(ssl_ctx, SSL_VERIFY_PEER, nullptr);

    //SSL_CTX_set_verify_depth(ssl_ctx, 1);
    //SSL_CTX_set_tlsext_servername_callback(ssl_ctx, svr_name_callback);
#endif

    return ssl_ctx;
}

int create_ssl_context(ssl_session_t *session)
{
    session->ssl_new_ctx = create_ssl_ctx("sha2", session);
    session->ssl_old_ctx = create_ssl_ctx("sha2", session);

    return 0;
}

int handle_ssl_accept_client(ssl_session_t *session)
{
    int ret;

    create_ssl_context(session);

    session->client = accept(session->fd, nullptr, 0);

    session->ssl = SSL_new(session->ssl_old_ctx);
    if (!session->ssl) {
        printf("SSL_new() fail\n");
        return -1;
    }
    SSL_set_fd(session->ssl, session->client);

#if (0)
    SSL_set_cert_cb(ssl, cert_callback, nullptr);
#endif

    if ((ret = SSL_accept(session->ssl)) != 1) {
        ERR_print_errors_fp(stderr);
        close(session->client);
        SSL_free(session->ssl);
        return -1;
    }

    if (session->verify_peer) {
        X509 *cert = SSL_get_peer_certificate(session->ssl);
        if (cert) {
            long ret = SSL_get_verify_result(session->ssl);
            if (ret != X509_V_OK) {
                ERR_print_errors_fp(stderr);
                printf("verify client failed\n");
            } else {
                printf("verify client ok\n");
            }
            X509_free(cert);
        } else {
            printf("no peer certificate\n");
        }
    }

    session->connected = true;
    session->connected_count++;

    return 0;
}

#if (0)
static X509 *load_cert(const char *file)
{
    X509 *x = nullptr;
    BIO *err = nullptr, *cert = nullptr;

    cert = BIO_new(BIO_s_file());
    if (cert == nullptr) {
        ERR_print_errors(err);
        goto end;
    }

    if (BIO_read_filename(cert, file) <= 0) {
        BIO_printf(err, "Error opening %s\n", file);
        ERR_print_errors(err);
        goto end;
    }

    x = PEM_read_bio_X509_AUX(cert, nullptr, nullptr, nullptr);

end:
    if (x == nullptr) {
        BIO_printf(err, "unable to load certificate\n");
        ERR_print_errors(err);
    }
    if (cert != nullptr) {
        BIO_free(cert);
    }
    return (x);
}

static int svr_name_callback(SSL *ssl, int *a, void *b)
{
    if (!ssl) {
        return SSL_TLSEXT_ERR_NOACK;
    }

    const char *svrname = SSL_get_servername(ssl, TLSEXT_NAMETYPE_host_name);
    if (!svrname || svrname[0] == '\0') {
        return SSL_TLSEXT_ERR_NOACK;
    }

    /* loading certificate based on sni */
    printf("svrname:%s\n", svrname);

    return SSL_TLSEXT_ERR_OK;
}
#endif

static int ana_ext_callback(SSL *ssl, unsigned int ext_type,
                            const unsigned char *in, size_t inlen, int *al, void *arg)
{
    char ext_buf[2048] = { 0 };
    char *tag = nullptr;
    char cust_tag[1024] = { 0 };

    memcpy(ext_buf, in, inlen);

    //printf("---ext parse callback---\n");

    tag = strstr(ext_buf, "sign_algo=");
    if (tag) {
        sprintf(cust_tag, "%s", tag + strlen("sign_algo="));
    }

    printf("---cert tag [%s]----\n", cust_tag);

    ssl_session_t *session = (ssl_session_t *) arg;

    SSL_set_SSL_CTX(ssl, session->ssl_new_ctx);

    return 1;
}

#if (0)
static int cert_callback(SSL *ssl, void *a)
{

    printf("------certificate callback %p-------\n", ssl_new_ctx);

    //SSL_set_SSL_CTX(ssl, ssl_new_ctx);

#if (0)
    SSL_set_verify(ssl, SSL_CTX_get_verify_mode(ssl_new_ctx),
                   SSL_CTX_get_verify_callback(ssl_new_ctx));

    SSL_set_options(ssl, SSL_CTX_get_options(ssl_new_ctx));
#endif

    return 1;
}
#endif

#endif /* HELP_CC_ */
