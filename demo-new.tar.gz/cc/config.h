///
/// simple configuration
///

#ifndef CONFIG_H_INCLUDED
#define CONFIG_H_INCLUDED

using conf_map_t = std::multimap<std::string, std::pair<int,std::string>>;

int init_listen_port();

#endif
