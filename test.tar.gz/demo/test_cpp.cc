
#include <iostream>
#include <string>

int main()
{
    std::string msg = "how are you doing";
    std::cout << msg << "\n";
    
    return 0;
}

