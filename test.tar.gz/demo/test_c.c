#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("how are you doing?\n");
    return 0;
}
