//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Script.rc
//
#define IDS_TIP                         1
#define IDI_ICON1                       101
#define IDI_TRAYICON                    101
#define IDR_POPUP                       102
#define IDD_CONVERTER                   103
#define IDC_CODEPAGE                    1000
#define IDC_TEXT                        1001
#define IDC_REFRESH                     1002
#define ID_SHOW                         40001
#define ID_QUIT                         40002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
