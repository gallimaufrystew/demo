/*
 * File:   atuns.cpp
 * Author: 19020107
 *
 * Created on May 03, 2018, 4:34 PM
 */

#include "atun_signal.h"
#include "atun_config.h"
#include "atun_socket.h"
#include "atun_mem.h"
#include "atun_connection.h"
#include "atun_ssl.h"

extern sig_atomic_t sig_exit;

int main(int argc, char *argv[])
{
    atun_init_config();

    init_signal();

    //atun_mem_init();

    atun_event_process_init();

    atun_init_connection();

    int ret = atun_init_listen_socket();
    if (ret <= 0) {
        std::cout << "init_listen_socket...\n";
        return -1;
    }

    atun_add_listen_read_event(ret);

    atun_init_ssl_lib();

    std::cout << "start handling event...\n";

    for (;;) {

        if (sig_exit) {
            break;
        }

        atun_process_events(1000);

        atun_process_posted_event();

        atun_check_timeout();
    }

    /* atun_process_exit 
     * todo...cleanup
     */

    return 0;
}
