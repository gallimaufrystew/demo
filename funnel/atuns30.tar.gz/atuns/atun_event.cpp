
#include "atun_event.h"
#include "atun_connection.h"
#include "atun_ssl.h"

atun_event_action_t atun_event_action;

extern atun_event_action_t select_action;
extern atun_event_action_t epoll_action;

static atun_event_queue  atun_posted_events;

extern atun_buf_queue up_bufs;
extern atun_connection all_conns;
extern atun_buf_list ssl_write_list, ssl_read_list;

void atun_event_process_init()
{

#if (USE_EPOLL)

    atun_event_action = epoll_action;

#elif (USE_KQUEUE)
///////////////////////////////////////
#elif (USE_EVENT_PORT)
///////////////////////////////////////
#else
    atun_event_action = select_action;
#endif

    atun_event_action.init();
}

void atun_cleanup_one_upconn(atun_connection_t *uc)
{
    std::cout << "cleanup...." << "\n";

    atun_del_conn(uc, 0);
    atun_cleanup_one(up_bufs[uc->suid]);
    up_bufs.erase(uc->suid);
    all_conns.erase(uc->suid);
    atun_close_sock(uc->fd);
#if (1)
    atun_free_connection(uc);
#endif
}

void atun_process_posted_event()
{
    std::set<atun_connection_t*> conns;

    while (!atun_posted_events.empty()) {

        atun_event_t *ev = atun_posted_events.front();

        atun_posted_events.pop();

        atun_connection_t *c = (atun_connection_t*)ev->data;

        // non-active connection
        if (c->eof) {
            conns.insert(c);
            continue;
        }

        ev->handler(ev);
    }

    // cleanup up connection
    for (auto it = conns.begin(); it != conns.end(); ++it) {
        atun_cleanup_one_upconn(*it);
    }
}

void atun_post_event(atun_event_t *ev)
{
    atun_posted_events.push(ev);
}

void atun_cleanup_event_queue()
{
    std::queue<atun_event_t*> empty;
    std::swap(atun_posted_events, empty);
}

void debug_check()
{
    for (auto it = up_bufs.begin(); it != up_bufs.end(); ++it) {
        std::cout << "queue size ... "
                << it->first << " "
                << it->second.size()
                << "\n";
    }

    for (auto it = ssl_write_list.begin(); it != ssl_write_list.end(); ++it) {
        std::cout << "ssl_write_list size ... "
                << it->second
                << "\n";
    }
}

void atun_check_timeout()
{
    time_t current = time(NULL);

    // over 20 seconds elapsed with no activity
    for (auto it = all_conns.begin(); it != all_conns.end(); ++it) {
        auto uc = it->second;
        if (difftime(current, uc.second) >= 20) {
            //std::cout << "timeout...." << "\n";
            uc.first->eof = 1;
            //atun_cleanup_one_upconn(uc.first);
        }
    }

    //debug_check();
}
