/*******************************************************************************
 * file:        2ndfactor.c
 * author:      ben servoz
 * description: PAM module to provide 2nd factor authentication
 * notes:       instructions at http://ben.akrin.com/?p=1068
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <security/pam_appl.h>
#include <security/pam_modules.h>

/* expected hook */
PAM_EXTERN int pam_sm_setcred( pam_handle_t *pamh, int flags, int argc, const char **argv ) {
	return PAM_SUCCESS ;
}


/* this function is ripped from pam_unix/support.c, it lets us do IO via PAM */
int converse( pam_handle_t *pamh, int nargs, struct pam_message **message, struct pam_response **response ) {
	int retval ;
	struct pam_conv *conv ;

	retval = pam_get_item( pamh, PAM_CONV, (const void **) &conv ) ; 
	if( retval==PAM_SUCCESS ) {
		retval = conv->conv( nargs, (const struct pam_message **) message, response, conv->appdata_ptr ) ;
	}

	return retval ;
}


/* expected hook, this is where custom stuff happens */
PAM_EXTERN int pam_sm_authenticate( pam_handle_t *pamh, int flags,int argc, const char **argv ) {
	int retval ;
	int i ;
    
	/* these guys will be used by converse() */
	char *input ;
	struct pam_message msg[1],*pmsg[1];
	struct pam_response *resp;
	
	/* getting the username that was used in the previous authentication */
	const char *username ;
    if( (retval = pam_get_user(pamh,&username,"login: "))!=PAM_SUCCESS ) 
	{
		return retval ;
	}

	/* generating a random one-time code */
	char code[5] = "1234";
	code[4] = 0;


	/* setting up conversation call to display message */
	pmsg[0] = &msg[0];
	msg[0].msg_style = PAM_TEXT_INFO;
	msg[0].msg = "Enter SecureLink Session ID";
	resp = NULL;
	retval = converse(pamh, 1, pmsg, &resp);
	/*if ((retval = converse(pamh, 1, pmsg, &resp)) != PAM_SUCCESS)
	{
		resp[0].resp = NULL;
	}*/

	/* setting up conversation call prompting user to enter code */
	//pmsg[0] = &msg[0] ;
	//msg[0].msg_style = PAM_PROMPT_ECHO_ON;
	msg[0].msg_style = PAM_PROMPT_ECHO_ON;
	msg[0].msg = ""; //Left empty as this does not display.
	resp = NULL ;
	if( (retval = converse(pamh, 1 , pmsg, &resp))!=PAM_SUCCESS ) 
	{
		// if this function fails, make sure that ChallengeResponseAuthentication in sshd_config is set to yes
		return retval ;
	}

	/* retrieving user input */
	if( resp ) 
	{
		if( (flags & PAM_DISALLOW_NULL_AUTHTOK) && resp[0].resp == NULL ) 
		{
	    		free( resp );
	    		return PAM_IGNORE;
		}
		input = resp[ 0 ].resp;
		resp[ 0 ].resp = NULL; 		  				  
    } 
	else 
	{
		return PAM_IGNORE;
	}
	
	/* comparing user input with known code */
	if( strcmp(input, code)==0 ) {
		/* good to go! */
		free( input ) ;
		return PAM_SUCCESS ;
	} 
	else 
	{
		/* wrong code */
		free( input ) ;
		return PAM_AUTH_ERR;
	}

	/* we shouldn't read this point, but if we do, we might as well return something bad */
	return PAM_IGNORE;
}
