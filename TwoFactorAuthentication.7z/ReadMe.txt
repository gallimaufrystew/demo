Scope:
This project is originally intented to be used with 64bit Ubuntu VM.

The source file is a Linux PAM (Pluggable Authentication Module) shared object (.so) file. It's intent is to provide two factor authintication via SecureLink. It will prompt the user for a SecureLink Session ID and then validate the session id against SecureLink. 

Note: The souce file twofactor.c is baised on code found at http://ben.akrin.com/?p=1068.
Note: The build-install script is also baised on the build steps mentioned at http://ben.akrin.com/?p=1068. However, the location of the pam modules is a different location and I had to use a different compliler for 64bit linux.

Build / Install:
1. Copy all of the files in source control to the vm-share (or the Ubuntu box)
2. Open a terminal emulator and type "./build-install". Note: this will need administrative privialges, enter the admin password when prompted.

The build-install script will:
1. Download any dependancy packages.
2. Build twofactor.c for 64bit cpu.
3. Change permissions of the output file (twofactor.so)
4. Copy twofactor.so and lightdm to the appropriate directories. 

Misc:
lightdm is the PAM configuration file for lightdm. It is located in /etc/pam.d/lightdm. We change modify it so it will load our twofactor.so file to vailidate against SecureLink.

Other PAM resourses are listed in the DeveloperNotes document.

Known Issues:
1. Sometimes when running the install script it will fail because a folder cannot be found. It seems that it is caused by Ubuntu downloading updates. Reboot the box, this will finish installing the updates at login. Then run the script again.