
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <map>

extern std::map<int, std::pair<std::string, int>> port_maps;

int init_port_mapping()
{
    std::ifstream ifs("tuns.conf");
    std::string line;

    if (ifs.is_open() == false) {
        std::cout << "configuration file doesn't exist\n";
        exit(-1);
    }

    while (std::getline(ifs, line)) {
        std::string key,pair_first,pair_second;
        std::istringstream is(line);
        is >> key >> pair_first >> pair_second;
        
        if (key.size()) {
            if (key[0] == '#') continue;
            if (key[0] != ' ') {
                port_maps[std::atoi(key.c_str())] = make_pair(pair_first,std::atoi(pair_second.c_str()));
            }
        }
    }
    ifs.close();

    return 0;
}
