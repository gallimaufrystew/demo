
#include "atun_event.h"

//static event_queue  atun_posted_accept_events;
static event_queue  atun_posted_events;

void atun_process_posted_event()
{
    while (!atun_posted_events.empty()) {

        atun_event_t *ev = atun_posted_events.front();

        atun_posted_events.pop();

        ev->handler(ev);
    }
}

void atun_post_event(atun_event_t *ev)
{
    atun_posted_events.push(ev);
}
