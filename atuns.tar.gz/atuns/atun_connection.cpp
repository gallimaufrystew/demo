
#include "atun_connection.h"
#include "atun_ssl.h"
#include "config.h"

static connection_list free_connections;
extern port_map_t port_map;

int atun_event_accept(atun_event_t *ev)
{
    atun_connection_t *c = static_cast<atun_connection_t *>(ev->data);
    int client = accept(c->fd, nullptr, 0);
    if (client <= 0) {
        return -1;
    }

    atun_set_nonblock(client);

    int n = atun_init_ssl_session();
    if (n != 0) {
        std::cout << "atun_init_ssl_session\n";
    }
    
    atun_connection_t *nc = get_connection();
    if (nc == nullptr) {
        atun_close_sock(client);
        return -1;
    }

    nc->fd = client;
    nc->read_event->accept = 0;
    nc->read_event->write = 0;
    nc->read_event->index = ATUN_INVALID_INDEX;
    nc->read_event->handler = atun_ssl_handshake;

    atun_select_add_event(nc->read_event, ATUN_READ_EVENT, 0);    
    
    return 0;
}

atun_connection_t* get_connection()
{
    atun_connection_t *c = nullptr;
    if (free_connections.size()) {
        c = free_connections.front();
        free_connections.pop_front();
    }
    return c;
}

void atun_init_connection(int max_connection)
{
    size_t conn_size = sizeof(atun_connection_t);
    size_t event_size = sizeof(atun_event_t);
    
    for (int i = 0; i < max_connection; ++i) {
        atun_connection_t *c = 
            static_cast<atun_connection_t*>(atun_alloc(conn_size));
        
        c->read_event = 
            static_cast<atun_event_t*>(atun_alloc(event_size));
        c->read_event->data = c;
        
        c->write_event = 
            static_cast<atun_event_t*>(atun_alloc(event_size));
        c->write_event->data = c;
        free_connections.push_back(c);
    }
}

int atun_upstream_read(atun_event_t *ev)
{
    atun_connection_t *uc = static_cast<atun_connection_t *>(ev->data);
    u_char buf[DATA_SIZE] = {};
    
    int n = recv(uc->fd, buf + PROTO_SIZE, DATA_SIZE - PROTO_SIZE, 0);
    if (n <= 0) {
        if (errno == EINTR || errno == EWOULDBLOCK || errno == EAGAIN) {
            return 0;
        }
        return -1;
    }
    
    uint32_t  nlen;
    nlen = htonl(n);
    memcpy(buf, &nlen, 4);

    // now port is of no importance
    // for simplicity we omit it

    // which session ?
    // it's a tricky part

    uint32_t nsuid;
    nsuid = htonl(uc->suid);
    memcpy(buf + 8, &nsuid, 4);
    
    size_t size = n + PROTO_SIZE;

    u_char *data = static_cast<u_char*>(atun_alloc(size)), *last = data;
    std::memcpy(data, buf, size);
    auto queue = uc->down->queue;
    queue.push_back(std::make_pair(last, size));

    return 0;
}

int atun_upstream_write(atun_event_t *ev)
{
    atun_connection_t *c = static_cast<atun_connection_t *>(ev->data);
    auto queue = c->queue;
    if (!queue.empty()) {
        auto item = queue.front();
        queue.pop_front();
        int n = send(c->fd, item.first, item.second, 0);
        if (n <= 0) {
            if (errno == EINTR || errno == EWOULDBLOCK) {
                queue.push_front(item);
                return 0;
            }
            // todo fatal error
            std::cout <<  __func__ << " fatal " << errno << "\n";
            return -1;
        }

        if (n < item.second) {
            item.second -= n;
            item.first += n;
            queue.push_front(item);
        }
    }
    return 0;
}
