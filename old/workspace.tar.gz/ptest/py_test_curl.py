
# coding=gbk

import pycurl
import hashlib
import cStringIO
from urllib import quote, unquote
# import datetime
import time

buf = cStringIO.StringIO()

now_time = time.strftime('%Y-%m-%d', time.localtime(time.time()))
key = 'dca51ef03e778c12147b749645ba3b33'

sms_text = '���ã����ĺ���khalid��ף��ÿ����֣�ƾ����Ϣ����2013-03-08ǰ����ȡ�������µĲ�Ʒ����';
mms_title = '���԰�'
mms_text = '���ã����ĺ���khalid��ף��ÿ����֣�ƾ����Ϣ����2013-03-08ǰ����ȡ�������µĲ�Ʒ����'

kvs = {"merchant_id" : "00002426",
         "format" : "xml",
         "channel_id" : "0000000011",
         "method" : "generate_certificate",
         "mobile" : "13817569470",
         "sign_method" : "md5",
         "v" : "1.0",
         "use_days" : "45",
         "send_type" : "BMS",
         "order_id" : "0000000000000005",
         "goods_id" : "333333244",
         "req_seq" : "000000000001112"}

sign = ''
vbuf = ''

kvs['sms_text'] = sms_text.decode('gbk').encode('utf8')
kvs['mms_title'] = mms_title.decode('gbk').encode('utf8')
kvs['mms_text'] = mms_text.decode('gbk').encode('utf8')

kvs['timestamp'] = now_time

print kvs

for item in sorted(kvs.items(), key=lambda d : d[0]):
        vbuf += item[0] + item[1]
        sign = hashlib.md5(key + vbuf + key).hexdigest().lower()

kvs['sms_text'] = quote(sms_text)
kvs['mms_title'] = quote(mms_title)
kvs['mms_text'] = quote(mms_text)

print kvs

vbuf = ''
for item in kvs.items():
        vbuf += item[0] + '=' + item[1] + '&'

vbuf += 'sign=' + sign

print vbuf

c = pycurl.Curl()
c.setopt(c.URL, 'http://222.44.51.34:9301/cpserver.do')
c.setopt(c.CONNECTTIMEOUT, 30)
c.setopt(c.TIMEOUT, 30)
c.setopt(c.VERBOSE, True)
c.setopt(c.WRITEFUNCTION, buf.write)

# c.setopt(c.FAILONERROR, True)
# c.setopt(c.HTTPHEADER, ['Accept: text/html', 'Accept-Charset: UTF-8'])

try:
        c.setopt(c.POSTFIELDS, vbuf)
        c.perform()
except pycurl.error, error:
        errno, errstr = error
        print 'An error occurred: ', errstr

print unquote(buf.getvalue())
buf.close()
