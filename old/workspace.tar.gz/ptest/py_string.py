
# coding=utf8

# about lists

a = ['spam', 'eggs', 100, 1234]

print a[0]

print a[3]

print a[-2]

print a[1:-1]

print a[:2] + ['bacon', 2*2]

print 2*a[:3]*2 + ['Boo!']

a = u'山水有灵，亦当惊知己于千古矣'.encode('utf-8')

print a

print u"äöü".encode('utf-8')
