
# coding=utf8

import hashlib

#src = 'teststring'
#print (hashlib.md5(src).hexdigest().upper())

d2 = {"a" : "apple", "b" : "grape", "c" : "orange", "d" : "banana"}
print d2  

print d2['a'][0]

sign = ''
vbuf = ''
for item in sorted(d2.items(), key = lambda d : d[0]):
    vbuf += item[0] + item[1]
    sign = hashlib.md5(vbuf)
    #print item[0],

print sign.hexdigest().lower()

