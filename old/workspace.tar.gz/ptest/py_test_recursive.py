
#filename = raw_input('Enter file name: ')
fobj = open('/home/huxk/temp/bundles.info', 'r')
lines = 0
for eachLine in fobj:
    print eachLine,
    lines += 1

fobj.close()

print lines

def print_tuple(aTuple):
    for i in range(len(aTuple)):
        if isinstance(aTuple[i],tuple):
            print_tuple(aTuple[i])
        else:
            print aTuple[i],

#print_tuple((1,2,(1,2,3,4),1,2,(1,2,3)))

def traverse(o, tree_types=(list, tuple)):
    if isinstance(o, tree_types):
        for value in o:
            for subvalue in traverse(value):
                yield subvalue
    else:
        yield o

data = [(1,1,(1,1,(1,"1"))),(1,1,1),(1,),1,(1,(1,("1",)))]
print list(traverse((1,2,(1,2,3,4),1,2,(1,2,3))))

m = yield 5
print m



