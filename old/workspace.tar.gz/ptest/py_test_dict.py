
# coding=gbk

dic = {'a':'aa','b':'bb'}

print dic

#modify
dic['a'] = '111111'

print dic

