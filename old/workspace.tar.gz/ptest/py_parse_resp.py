
#coding=gbk

import xml.etree.ElementTree as ET

# python's way of parsing xml

tree = ET.parse('expense_resp.xml')
root = tree.getroot()

# just get it
print root[5][0][0].text
print root[5][0][1].text
print root[5][0][2].text

# xpath
for a in root.findall('./award_result_list/award_result'):
    print a.find('award_level').text,
    print a.find('goods_id').text,
    print a.find('award_num').text

    