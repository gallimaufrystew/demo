

def say():
        print 'say in'

apply(say);

def say1(a,b):
        print a,b

apply(say1,('hello','python'))

def say2(a=1,b=2):
        print a,b

def haha(**kw):    
        # say(kw)
        apply(say2,(),kw)

print haha(a='a',b='b')


