
#coding = utf8

# unpacking keywords list

def my_function():
    """Do nothing, but document it.
    
    No, really, it doesn't do anything."""
    pass

print my_function.__doc__

def make_incrementor(n):
    return lambda x: x + n

f = make_incrementor(42)
print f(1)

def parrot(voltage, state='a stiff', action='voom'):
    print "-- This parrot wouldn't", action,
    print "if you put", voltage, "volts through it.",
    print "E's", state, "!"

d = {"voltage": "four million", "state": "bleedin' demised", "action": "VOOM"}
parrot(**d)
