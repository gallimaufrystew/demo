
a = ['spam', 'eggs', 100, 1234]

a[2] += 23

print a

a[1:2] = [];

print a
