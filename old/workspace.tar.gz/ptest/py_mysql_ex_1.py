#!/usr/bin/python
# -*- coding: utf-8 -*-

import MySQLdb as mdb
import sys

con = None

try:
    con = mdb.connect('222.44.51.34', 'imgshop','imgshop', 'imgshop');
    cur = con.cursor(mdb.cursors.DictCursor)

    sql = """
    select presented_seq, 
        order_id,mms_info
        from order_wait_send_info
    """
    cur.execute(sql)
    rows = cur.fetchall()
    
    """
        numrows = int(cur.rowcount)
    
        for i in range(numrows):
            row = cur.fetchone()
            print row[0], row[1]
    """
    
    for row in rows:
        print "%s %s %s" % (row["presented_seq"], row["order_id"],row['mms_info'])
    
except mdb.Error, e:
    print "Error %d: %s" % (e.args[0],e.args[1])
    sys.exit(1)
    
finally:
    if con:    
        con.close()