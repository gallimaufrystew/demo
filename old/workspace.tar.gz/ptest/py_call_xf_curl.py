
# coding=utf8

import pycurl
#import hashlib
import cStringIO
#from urllib import quote, unquote
# import datetime
#import time

buf = cStringIO.StringIO()

c = pycurl.Curl()
c.setopt(c.URL, 'http://218.94.114.155/xfcj_serv/serv.php')
c.setopt(c.CONNECTTIMEOUT, 30)
c.setopt(c.TIMEOUT, 30)
#c.setopt(c.VERBOSE, True)
c.setopt(c.WRITEFUNCTION, buf.write)

# c.setopt(c.FAILONERROR, True)
# c.setopt(c.HTTPHEADER, ['Accept: text/html', 'Accept-Charset: UTF-8'])

#obuf = '<?xml version="1.0" encoding="gb2312"?><business_trans><request_type>awardquery_request</request_type><pos_id>1000010721</pos_id><pos_seq>130305023395</pos_seq><card_no>1000113200006285192</card_no></business_trans>'

#obuf = '<?xml version="1.0" encoding="gb2312"?><business_trans><request_type>awardquery_request</request_type><pos_id>1000010721</pos_id><pos_seq>130305023395</pos_seq><card_no>1000113200006285192</card_no></business_trans>';

obuf = '<?xml version="1.0" encoding="gb2312"?><business_trans><pos_id>1000010721</pos_id><pos_seq>130305023395</pos_seq><request_type>expense_request</request_type><transactionid>20130201135119001360</transactionid><card_no>1000113200000672120</card_no><node_no>32000002</node_no><request_time>20130228135119</request_time><expense_count>1</expense_count><expense_list><expense_info><expense_id>002993</expense_id><expense_amount>16144</expense_amount><expense_time>20130306133646</expense_time><device_id>133500008044</device_id><over_amount>000000</over_amount><trans_type>93</trans_type><goods_type/></expense_info></expense_list></business_trans>'

try:
        c.setopt(c.POSTFIELDS, obuf)
        c.perform()
except pycurl.error, error:
        errno, errstr = error
        print 'An error occurred: ', errstr

print buf.getvalue().decode('gbk').encode('utf8')

buf.close()
