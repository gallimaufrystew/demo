/*
 * string.h
 *
 *  Created on: Aug 29, 2012
 *      Author: huxk
 */

#ifndef __STRING_H__
#define __STRING_H__

#include <iconv.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
/* #include "md5.h" */
#include <openssl/md5.h>

#define img_tolower(c) (u_char) ((c >= 'A' && c <= 'Z') ? (c | 0x20) : c)
#define img_toupper(c) (u_char) ((c >= 'a' && c <= 'z') ? (c & ~0x20) : c)

void escape_string(char * src,
		unsigned int src_len,
		char * dest,
		unsigned int dest_len);
char* unescape_string(char *ibuf, char *obuf);
void calc_mac(u_char *ibuf, unsigned int ilen, u_char *omac);
char *convert_enc(char *from, char *to, char *in);

#endif /* __STRING_H__ */
