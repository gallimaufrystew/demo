/*
 * buz.h
 *
 *  Created on: 2012-9-6
 *      Author: huxk
 */

#ifndef __BUZ_H__
#define __BUZ_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errmsg.h>
#include <stddef.h>
#include <signal.h>
#include <mysql.h>
#include <errno.h>
#include <math.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/types.h>
#include "set_proc_title.h"
#include "cfg.h"
#include "utl.h"
#include "fldmap.h"

config_t config;

int get_col_len(MYSQL_RES *res, MYSQL_ROW linep, key_idx_t *ki);
int get_col_idx(MYSQL_RES *res, key_idx_t *ki);
int diff_record(void *data);
int make_label(void *data);
int make_label_pic(MYSQL *conn, key_idx_t *pmain_map,config_t *cfg);
void get_current_time(char *time_now);
char* get_value(key_idx_t *kidx, char *fldname);
int abnormal_exit_process(MYSQL *conn);

#endif /* __BUZ_H__ */
