/*
 * cfg.c
 *
 *  Created on: Aug 28, 2012
 *      Author: huxk
 */

#include "cfg.h"

static inline u_char *ltrim(u_char *s, u_char c);
static inline u_char *rtrim(u_char *s, u_char c);
static inline u_char *alltrim(u_char *s, u_char c);

int load_config(config_t *cfg)
{
	FILE *fp = NULL;
	char buf[1024] = {0};
	char key[64] = {0};
	char value[512] = {0};
	char *pkey, *pvalue;
	int len;
	char conf_path[512] = {0};
	char cfgname[] = "conf.ini";

	snprintf(conf_path,
		sizeof(conf_path),
		"%s%s",
		getenv("SND_CFG_PATH"),
		cfgname);
	fp = fopen(conf_path, "r");

	if (fp != NULL) {
		memset(buf, 0, sizeof(buf));

		while (fgets(buf, sizeof(buf), fp) != NULL) {
			sscanf(buf, "%[^=] = %[^;#\n]", key, value);

			pkey = (char *)alltrim((u_char *)key, ' ');
			pvalue = (char *)alltrim((u_char *)value, ' ');
			len = strlen(pvalue);

			if (memcmp(pkey, "dbhost", 6) == 0) {
				memcpy(cfg->db_host, pvalue, len);
			}

			if (memcmp(pkey, "dbuser", 6) == 0) {
				memcpy(cfg->db_user, pvalue, len);
			}

			if (memcmp(pkey, "dbpass", 6) == 0) {
				memcpy(cfg->db_pass, pvalue, len);
			}

			if (memcmp(pkey, "dbname", 6) == 0) {
				memcpy(cfg->db_name, pvalue, len);
			}

			if (memcmp(pkey,
				"product_label_uri",
				strlen("product_label_uri")) == 0) {
				memcpy(cfg->product_label_uri, pvalue, len);
			}

			if (memcmp(pkey,
				"zip_file_prefix",
				strlen("zip_file_prefix")) == 0) {
				memcpy(cfg->zip_file_prefix, pvalue, len);
			}

			if (memcmp(pkey,
				"no_data_sleep_time",
				strlen("no_data_sleep_time")) == 0) {
				cfg->sleep_time = atoi(pvalue);
			}

			if (memcmp(pkey,
				"proc_limit",
				strlen("proc_limit")) == 0) {
				cfg->proc_limit = atoi(pvalue);
			}
		}

		fclose(fp);

		return 0;
	}

	return -1;
}

static inline u_char *ltrim(u_char *s, u_char c)
{
	if (c)
		while (*s == c)
			s++;

	return s;
}

static inline u_char *rtrim(u_char *s, u_char c)
{
	u_char *p = s + strlen((char *)s);

	while (p-- > s)
		if (*p == c)
			*p = '\0';
		else
			break;
	return s;
}

static inline u_char *alltrim(u_char *s, u_char c)
{
	rtrim(s, c);
	return ltrim(s, c);
}

