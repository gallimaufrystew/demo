/*
 * fldmap.h
 *
 *  Created on: 2012-9-7
 *      Author: huxk
 */

#ifndef __FLDMAP_H__
#define __FLDMAP_H__

typedef struct _fld_indx_map_t
{
	char *fldname;
	int index;
} fld_indx_map_t;

typedef enum _enum_t
{
	FLD_NAME_LEN = 128, MAX_SEL_COLS = 32
} enum_t;

typedef struct _key_idx_len_t
{
	char name[FLD_NAME_LEN];
	int idx;
	unsigned int len;
	char *fldvp;
} key_idx_len_t;

typedef struct _key_idx_t
{
	int cols;
	key_idx_len_t kidx[MAX_SEL_COLS];
} key_idx_t;

#endif /* __FLDMAP_H__ */
