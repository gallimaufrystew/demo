
/*
 * Copyright (C)
 * Copyright (C) Inc.
 */


#ifndef __SET_PROC_TITLE_H__
#define __SET_PROC_TITLE_H__

#include <string.h>
#include <stddef.h>
#include "utl.h"

#define SETPROCTITLE_USES_ENV  1
#define SETPROCTITLE_PAD       '\0'

int init_set_proc_title();
void set_proc_title(char *title);

extern char **os_argv;
u_char child_process_name[4096*2];

#endif /* __SET_PROC_TITLE_H__ */
