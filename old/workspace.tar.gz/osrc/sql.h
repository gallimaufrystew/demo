/*
 * sql.h
 *
 *  Created on: 2012-9-7
 *      Author: huxk
 */

#ifndef __SQL_H__
#define __SQL_H__

/*****************************************************************/
const char *select_batch_label_sql = "select id,node_id, "
				"batch_no,"
				"product_id,"
				"level "
				"from batch_label "
				"where status = '%c' "
				"limit 100";
/*****************************************************************/

#endif /* __SQL_H__ */
