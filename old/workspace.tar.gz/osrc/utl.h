/*
 * utl.h
 *
 *  Created on: Aug 29, 2012
 *      Author: huxk
 */
#ifndef __UTL_H__
#define __UTL_H__

#include <time.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>

typedef void sigfunc(int);

int daemonize();
int log_err(const char*fmt, ...);
sigfunc *rsignal(int signo, sigfunc * func);

#endif /* __UTL_H__ */

