/*
 * process.c
 *
 *  Created on: 2012-9-10
 *      Author: huxk
 */

#include "process.h"

signal_t signals[] = { { SIGUSR1, "SIGUSR1", signal_handler },
		{ SIGWINCH,"SIGWINCH", signal_handler },
		{ SIGTERM, "SIGTERM",signal_handler },
		{ SIGQUIT, "SIGQUIT", signal_handler },
		{ SIGUSR2, "SIGUSR2", signal_handler },
		{ SIGINT, "SIGINT",signal_handler },
		{ SIGIO, "SIGIO", signal_handler },
		{ SIGCHLD, "SIGCHLD", signal_handler },
		{ SIGSYS, "SIGSYS", SIG_IGN },
		{ SIGPIPE, "SIGPIPE", SIG_IGN },
		{ SIGHUP, "SIGHUP", signal_handler },
		{ 0, NULL, NULL } };

process_t processes[MAX_PROCESSES];

#if (0)
void wait_all_processes(void) {
	int status;
	pid_t pid;

	while ((pid = wait(&status)) > 0) {
		log_err("one process [%d] done", pid);
	}
}
#endif

int get_batch_count(MYSQL *conn) {
	char sql[1024] = { 0 };
	int db_ret = 0;
	MYSQL_RES *result;
	MYSQL_ROW line;
	key_idx_t sqlmap;

	memset(sql, 0, sizeof(sql));
	strcpy(sql, "select count(id) rows "
			"from batch_label "
			"where status in ('1','3')");
	db_ret = mysql_query(conn, sql);
	if (db_ret == CR_SERVER_GONE_ERROR || db_ret == CR_SERVER_LOST) {
		log_err("mysql_query() failed");
		return -2;
	}

	result = mysql_store_result(conn);
	if (mysql_num_rows(result) == 0) {
		return 0;
	}

	get_col_idx(result, &sqlmap);

	line = mysql_fetch_row(result);

	get_col_len(result, line, &sqlmap);

	return atoi(get_value(&sqlmap, "rows"));
}

int dispatch_task(MYSQL *conn, config_t *cfg, int count) {
	int i;
	char sql[1024] = { 0 };
	int db_ret = 0;
	int proc_nums = 0;

	if (cfg->proc_limit == 0) {
		cfg->proc_limit = 5;
	}

	proc_nums = (count / cfg->proc_limit) + 1;

	if (proc_nums > 6) {
		proc_nums = 6;
	}

	for (i = 0; i < proc_nums; i++) {
		memset(sql, 0, sizeof(sql));
		snprintf(sql, sizeof(sql), "update batch_label "
				"set status ='%c' "
				"where status in ('1','3') limit %d",
				cfg->status[i], cfg->proc_limit);
		db_ret = mysql_query(conn, sql);
		if (db_ret == CR_SERVER_GONE_ERROR
				|| db_ret == CR_SERVER_LOST) {
			log_err("dispatch sql failed:\n[%s]", sql);
			mysql_close(conn);
			return -2;
		}

		/* process the dispatched */
		cfg->indx = i;
		processes[i].pid = spawn_process(make_label, cfg);
		log_err("one process %ld created",processes[i].pid);
	}

	return 0;
}

int main_process_cycle(config_t *cfg) {
	MYSQL *conn = NULL;
	int row_cnt = 0;

	set_proc_title("main_dispatch");

	db_fail: conn = mysql_init(NULL);

	mysql_real_connect(conn, (const char *) cfg->db_host,
			(const char *) cfg->db_user,
			(const char *) cfg->db_pass,
			(const char *) cfg->db_name, 0, NULL, 0);
	if (conn == NULL) {
		log_err("mysql_real_connect() failed");
		goto db_fail;
	}

	if (!mysql_set_character_set(conn, "gbk")) {
		log_err("charset %s", mysql_character_set_name(conn));
	}

	log_err("dispatch process [%ld]", getpid());

	for (;;) {
		row_cnt = get_batch_count(conn);
		if (row_cnt > 0) {
			if (dispatch_task(conn, cfg, row_cnt) == -2) {
				log_err("dispatch_task() failed");
				goto db_fail;
			}
		} else if (row_cnt == -2) {
			log_err("db failed");
			goto db_fail;
		} else {
			sleep(cfg->sleep_time);
			log_err("sleep,time [%d]", cfg->sleep_time);
			continue;
		}
	}

	return 0;
}

pid_t spawn_process(process_pt proc, void *data) {
	pid_t pid;
	pid = fork();

	switch (pid) {
	case -1:
		log_err("spawn child failed");
		return -1;
	case 0:
		proc(data);
		break;
	default:
		break;
	}

	return pid;
}

void signal_handler(int signo) {
	signal_t *sig;

	for (sig = signals; sig->signo != 0; sig++) {
		if (sig->signo == signo) {
			break;
		}
	}

	switch (signo) {
	case SIGQUIT:
		break;
	case SIGTERM:
	case SIGINT:
		break;
	case SIGWINCH:
		break;
	case SIGHUP:
		reload_config = 1;
		break;
	case SIGUSR1:
	case SIGUSR2:
		break;
	case SIGIO:
		break;
	case SIGCHLD:
		reap_child = 1;
		break;
	}

	log_err("signal [%d] (%s) received", signo, sig->signame);

	if (signo == SIGCHLD) {
		process_get_status();
	}
}

void process_get_status(void) {
	int status;
	char *process;
	pid_t pid;
	int err;
	//int i;
	unsigned int one;

	one = 0;

	for (;;) {
		pid = waitpid(-1, &status, WNOHANG);
		if (pid == 0) {
			return;
		}

		if (pid == -1) {
			err = errno;

			if (err == EINTR) {
				continue;
			}

			if (err == ECHILD && one) {
				return;
			}

			log_err("[%d][%s]", err, "waitpid() failed");
			return;
		}

		log_err("done process pid = [%d]", pid);

		one = 1;
		process = "done process";

#if (0)
		for (i = 0; i < 2; i++) {
			if (processes[i].pid == pid) {

				log_err("find one process");

				process = processes[i].name;
				processes[i].respawn = 1;
				break;
			}
		}
#endif

		if (WTERMSIG(status)) {
#ifdef WCOREDUMP
			log_err("%s %d exited on signal %d%s", process, pid,
					WTERMSIG(status),
					WCOREDUMP(status) ?
							" (core dumped)" : "");
#else
			log_err("%s %d exited on signal %d", process, pid,
					WTERMSIG(status));
#endif

		} else {
			log_err("%s %d exit code %d", process, pid,
					WEXITSTATUS(status));
		}

		if (WEXITSTATUS(status) == 2) {
			log_err("fatal,cannot be respawned");
		}
	}
}

int init_signals() {
	signal_t *sig;
	struct sigaction sa;

	for (sig = signals; sig->signo != 0; sig++) {
		memset(&sa, 0, sizeof(struct sigaction));
		sa.sa_handler = sig->handler;
		sigemptyset(&sa.sa_mask);
		if (sigaction(sig->signo, &sa, NULL) == -1) {
			log_err("sigaction(%s) failed", sig->signame);
			return -1;
		}
	}

	return 0;
}
