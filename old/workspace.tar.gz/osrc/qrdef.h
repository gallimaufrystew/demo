/*
 * qrdef.h
 *
 *  Created on: 2013-1-10
 *      Author: huxk
 */

#ifndef QRDEF_H_
#define QRDEF_H_

// need install libqrencode libzip
#include <png.h>
#include <getopt.h>
#include "zip.h"

// find it in /usr/local/include
#include "qrencode.h"

#define INCHES_PER_METER (100.0/2.54)

static int casesensitive = 1;
static int eightbit = 0;
static int version = 0;
static int size = 3;
static int margin = -1;
static int dpi = 72;
static int micro = 0;


static QRecLevel level = QR_ECLEVEL_L;
static QRencodeMode hint = QR_MODE_8;
static unsigned int fg_color[4] = {0, 0, 0, 255};
static unsigned int bg_color[4] = {255, 255, 255, 255};

#endif /* QRDEF_H_ */
