/*
 * utl.c
 *
 *  Created on: Aug 29, 2012
 *      Author: huxk
 */

#include "utl.h"
#include "cfg.h"
#include <errno.h>

int log_err(const char *fmt, ...)
{
	FILE *log;
	va_list args;
	char buf[10240] = {0};

	time_t curtime;
	unsigned int n = 0;
	struct tm *loctime;
	char log_path[512] = {0};
	char tmp[512] = {0};

	va_start(args, fmt);
	/* Get the current time. */
	curtime = time(NULL);
	/* Convert it to local time representation. */
	loctime = localtime(&curtime);
	memset(buf, 0x00, sizeof(buf));
	strftime(buf, 80, "[%Y-%m-%d %H:%M:%S] ", loctime);
	n = strlen(buf);
	vsnprintf(buf + n, sizeof(buf) - n, fmt, args);
	va_end(args);

	strftime(tmp, 40, "%Y%m%d.log", loctime);

	snprintf(log_path,
		sizeof(log_path),
		"%s%s",
		getenv("ENV_LOG_PATH"),
		tmp);
	log = fopen(log_path, "a+");
	if (log == NULL) {
		fprintf(stderr, "open log file error[%s]\n", tmp);
		fprintf(stderr, strerror(errno));
		return -1;
	}

	fprintf(log, "%u -> %s\n", getpid(), buf);

	fclose(log);

	return 0;
}

sigfunc *rsignal(int signo, sigfunc * func)
{
	struct sigaction act, oact;

	act.sa_handler = func;
	sigfillset(&act.sa_mask);
	act.sa_flags = 0;

#ifdef  SA_INTERRUPT
	act.sa_flags |= SA_INTERRUPT;
#endif

	sigaction(signo, &act, &oact);

	return oact.sa_handler;
}

int daemonize()
{
	int fd;

	switch (fork()) {
	case -1:
		return -1;

	case 0:
		break;

	default:
		exit(0);
	}

	if (setsid() == -1) {
		return -1;
	}

	umask(0);

	fd = open("/dev/null", O_RDWR);
	if (fd == -1) {
		return -1;
	}

	if (dup2(fd, STDIN_FILENO) == -1) {
		return -1;
	}

	if (dup2(fd, STDOUT_FILENO) == -1) {
		return -1;
	}

	if (fd > STDERR_FILENO) {
		if (close(fd) == -1) {
			return -1;
		}
	}

	return 0;
}

