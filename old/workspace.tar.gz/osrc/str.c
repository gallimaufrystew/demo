/*
 * string.c
 *
 *  Created on: Aug 29, 2012
 *      Author: huxk
 */

#include "str.h"
#include "utl.h"

void bcd2asc(u_char *bcd, u_char *asc, int len)
{
	int i;
	u_char ch;

	for (i = 0; i < len; i++)
	{
		ch = bcd[i] >> 4;
		asc[i * 2] = (ch > 9) ? ch - 10 + 'A' : ch + '0';
		ch = bcd[i] & 0x0f;
		asc[i * 2 + 1] = (ch > 9) ? ch - 10 + 'A' : ch + '0';
	}

	asc[2 * len] = '\0';

	return;
}

void lower_case(u_char *src, unsigned int n, u_char *dst)
{
	while (n)
	{
		*dst = img_tolower(*src);
		dst++;
		src++;
		n--;
	}

	dst[n] = '\0';

	return;
}

void calc_mac(u_char *ibuf, unsigned int ilen, u_char *omac)
{
	u_char tmpbuf[16] = {0};
	u_char buf[32] = {0};

	MD5_CTX md5_ctx;

	MD5_Init(&md5_ctx);
	MD5_Update(&md5_ctx, ibuf, ilen);
	MD5_Final(tmpbuf, &md5_ctx);

	bcd2asc(tmpbuf, buf, 16);

	lower_case(buf, 32, omac);

	log_err("md5 = [%s],buf = [%s]", omac, ibuf);
}

u_char char_to_hex(u_char x)
{
	return (u_char) (x > 9 ? x + 55 : x + 48);
}

int is_alpha_number_char(u_char c)
{
	if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')
			|| (c >= '0' && c <= '9'))
		return 1;

	return 0;
}

char* unescape_string(char *ibuf, char *obuf)
{
	char buf[10240] = { 0 };
	char *src = ibuf;
	char *dst = buf;

	if (ibuf == NULL)
	{
		return NULL;
	}

	memset(buf, 0x00, sizeof(buf));

	while (*src != 0)
	{
		if (*src == '%')
		{
			u_char h = img_toupper(src[1]);
			u_char l = img_toupper(src[2]);

			unsigned int vh, vl;
			vh = isalpha(h) ? (10 + (h - 65)) : (h - 48);
			vl = isalpha(l) ? (10 + (l - 65)) : (l - 48);

			*dst++ = (u_char) ((vh << 4) + vl);
			src += 3;
		}
		else if (*src == '+')
		{
			*dst++ = ' ';
			src++;
		}
		else
		{
			*dst++ = *src++;
		}
	}

	*dst = '\0';
	memcpy(obuf, buf, strlen((char *) buf));

	return obuf;
}

void escape_string(char * src,
		unsigned int src_len,
		char * dest,
		unsigned int dest_len)
{
	u_char ch;
	unsigned int len = 0;

	while (len < (dest_len - 4) && *src)
	{
		ch = (u_char) *src;
		if (*src == ' ')
		{
			*dest++ = '+';
		} else if (is_alpha_number_char(ch) || strchr("-_.!~*'()", ch))
		{
			*dest++ = *src;
		} else
		{
			*dest++ = '%';
			*dest++ = char_to_hex((u_char) (ch >> 4));
			*dest++ = char_to_hex((u_char) (ch % 16));
		}
		++src;
		++len;
	}

	*dest = 0;

	return;
}

char *convert_enc(char *from, char *to, char *in)
{
	static char out[10240];
	char *si, *so;
	size_t i_len, o_len;
	iconv_t c_pt;

	if ((c_pt = iconv_open(to, from)) == (iconv_t) -1)
	{
		log_err("iconv_open() failed");
		return NULL;
	}
	iconv(c_pt, NULL, NULL, NULL, NULL);

	i_len = strlen(in) + 1;
	o_len = sizeof(out) - 1;
	si = in;
	so = out;

	if (iconv(c_pt, &si, &i_len, &so, &o_len) == -1)
	{
		log_err("iconv() failed");
		return NULL;
	}
	iconv_close(c_pt);

	return out;
}
