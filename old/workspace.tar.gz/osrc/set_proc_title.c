/*
 * Copyright (C)
 * Copyright (C) Inc.
 */

#include "set_proc_title.h"

#if (SETPROCTITLE_USES_ENV)

extern char **environ;
static char *os_argv_last;
char **os_argv;

u_char *cpystrn(u_char *dst, u_char *src, size_t n)
{

	if (n == 0) {
		return dst;
	}

	while (--n) {
		*dst = *src;

		if (*dst == '\0') {
			return dst;
		}

		dst++;
		src++;
	}

	*dst = '\0';

	return dst;
}

int init_set_proc_title()
{

	u_char *p;
	size_t size;
	unsigned int i;

	size = 0;

	for (i = 0; environ[i]; i++) {
		size += strlen(environ[i]) + 1;
	}

	if (size > sizeof(child_process_name)) {
		return -1;
	}

	p = child_process_name;

	os_argv_last = os_argv[0];

	for (i = 0; os_argv[i]; i++) {
		if (os_argv_last == os_argv[i]) {
			os_argv_last = os_argv[i] + strlen(os_argv[i]) + 1;
		}
	}

	for (i = 0; environ[i]; i++) {
		if (os_argv_last == environ[i]) {
			size = strlen(environ[i]) + 1;
			os_argv_last = environ[i] + size;

			cpystrn(p, (u_char *) environ[i], size);
			environ[i] = (char *) p;
			p += size;
		}
	}

	os_argv_last--;

	return 0;
}

void set_proc_title(char *title)
{
	u_char *p;

	os_argv[1] = NULL;

	p = cpystrn((u_char *) os_argv[0],
		(u_char *) "label: ",
		os_argv_last - os_argv[0]);

	p = cpystrn(p, (u_char *) title, os_argv_last - (char *) p);

	if (os_argv_last - (char *) p) {
		memset(p, SETPROCTITLE_PAD, os_argv_last - (char *) p);
	}

	log_err("set_proc_title: \"%s\"", os_argv[0]);
}

#endif /* SETPROCTITLE_USES_ENV */
