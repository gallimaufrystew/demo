/*
 * buz.c
 *
 *  Created on: 2012-9-3
 *      Author: huxk
 */

#include "process.h"

extern config_t config;
extern char **os_argv;

void os_init(char **argv);

int main(int argc, char *argv[])
{
	os_init(argv);

	if (load_config(&config)) {
		fprintf(stderr, "load_config() failed\n");
		exit(0);
	}

	strcpy(config.status,"uvwxyz");

	log_err("[%s][%s][%s][%s]\n[%s][%s][%d][%d]",
		config.db_host,
		config.db_user,
		config.db_pass,
		config.db_name,
		config.zip_file_prefix,
		config.product_label_uri,
		config.sleep_time,
		config.proc_limit);

	if (config.zip_file_prefix[strlen(config.zip_file_prefix) - 1] != '/')
	{
		fprintf(stderr, "file prefix bad format [%s]\n",
				config.zip_file_prefix);
		exit(0);
	}

	if (init_signals()) {
		fprintf(stderr, "init_signals() failed\n");
		exit(0);
	}

	if (daemonize()) {
		fprintf(stderr, "daemonize() failed\n");
		exit(0);
	}

	main_process_cycle(&config);

	return 0;
}

void os_init(char **argv)
{
	os_argv = argv;
	init_set_proc_title();
}
