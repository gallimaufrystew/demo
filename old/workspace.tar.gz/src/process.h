/*
 * process.h
 *
 *  Created on: 2012-9-11
 *      Author: huxk
 */

#ifndef __PROCESS_H__
#define __PROCESS_H__

#include <sys/types.h>
#include <sys/wait.h>
#include "batch.h"

#define MAX_PROCESSES 64

typedef int (*process_pt)(void *data);

typedef struct
{
	pid_t pid;
	process_pt proc;
	int respawn;
	char batch_status;
	void *data;
	char *name;
} process_t;

typedef struct
{
	int signo;
	char *signame;
	void (*handler)(int signo);
} signal_t;

sig_atomic_t reap_child;
sig_atomic_t reload_config;
extern config_t config;

void process_get_status(void);
pid_t spawn_process(process_pt proc,void *data);
void main_process_cycle(config_t *cfg);
int init_signals();
void signal_handler(int signo);

#endif /* __PROCESS_H__ */
