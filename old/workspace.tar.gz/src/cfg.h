/*
 * cfg.h
 *
 *  Created on: Aug 27, 2012
 *      Author: huxk
 */

#ifndef __CFG_H__
#define __CFG_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PROCESSES 64
#define ARR_SIZE(a) (sizeof(a)/sizeof((a)[0]))

typedef struct _config_t {
	char db_host[64];
	char db_user[32];
	char db_pass[32];
	char db_name[64];
	char product_img_uri[1024];
	char zip_file_prefix[512]; 
	char product_label_uri[1024];
	char log_path[512];
	int sleep_time;
	int process_nums;
	int status_idx;
	char batch_status[MAX_PROCESSES];
} config_t;

int load_config(config_t *cf);

#endif /* __CFG_H__ */
