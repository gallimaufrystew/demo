/*
 * process.c
 *
 *  Created on: 2012-9-10
 *      Author: huxk
 */

#include "process.h"

signal_t signals[] = {{SIGUSR1, "SIGUSR1", signal_handler},
			{SIGWINCH,"SIGWINCH",signal_handler},
			{SIGTERM, "SIGTERM", signal_handler},
			{SIGQUIT,"SIGQUIT",signal_handler},
			{SIGUSR2, "SIGUSR2", signal_handler},
			{SIGINT, "SIGINT",signal_handler},
			{SIGIO, "SIGIO", signal_handler},
			{SIGCHLD, "SIGCHLD",signal_handler},
			{SIGSYS, "SIGSYS", SIG_IGN},
			{SIGPIPE, "SIGPIPE",SIG_IGN},
			{SIGHUP, "SIGHUP", signal_handler},
			{0, NULL, NULL}};

process_t processes[MAX_PROCESSES];

int get_batch_count(MYSQL *conn) {
	char sql[1024] = { 0 };
	int db_ret = 0;
	MYSQL_RES *result;
	MYSQL_ROW line;
	key_idx_t sqlmap;

	memset(sql, 0, sizeof(sql));
	strcpy(sql, "select count(id) rows "
			"from batch_label "
			"where status in ('1','3')");
	db_ret = mysql_query(conn, sql);
	if (db_ret == CR_SERVER_GONE_ERROR || db_ret == CR_SERVER_LOST) {
		log_err("mysql_query() failed");
		return -2;
	}

	result = mysql_store_result(conn);
	if (mysql_num_rows(result) == 0) {
		return 0;
	}

	get_col_idx(result, &sqlmap);

	line = mysql_fetch_row(result);

	get_col_len(result, line, &sqlmap);

	return atoi(get_value(&sqlmap, "rows"));
}

int dispatch_task(MYSQL *conn, config_t *cfg, int count)
{
	int i;
	char sql[1024] = { 0 };
	int db_ret = 0;
	int limit[MAX_PROCESSES] = {0};

	if (cfg->process_nums > MAX_PROCESSES){
		cfg->process_nums = MAX_PROCESSES;
	}
	
	for (i = 0;i < cfg->process_nums - 1;i++)
	{
		limit[i] = count / cfg->process_nums;
		log_err("process %d process %d rows,status %c",
			i,limit[i],
			cfg->batch_status[i]);
	}
	
	limit[i] = count - cfg->process_nums * limit[i - 1];
	log_err("process %d process %d rows,status %c",
		i,limit[i],
		cfg->batch_status[i]);

	for (i = 0; i < cfg->process_nums; i++) {
		if (limit[i])
		{
			memset(sql, 0, sizeof(sql));
			snprintf(sql, sizeof(sql), "update batch_label "
					"set status ='%c' "
					"where status in ('1','3') limit %d",
					cfg->batch_status[i], limit[i]);
			log_err("dispatch_sql:\n[%s]",sql);
			db_ret = mysql_query(conn, sql);
			if (db_ret == CR_SERVER_GONE_ERROR
					|| db_ret == CR_SERVER_LOST) {
				log_err("dispatch sql failed:\n[%s]", sql);
				mysql_close(conn);
				return -2;
			}
		}
	}

	return 0;
}

int dispatch_cycle(void *data) {

	MYSQL *conn = NULL;
	int row_cnt = 0;

	config_t *cfg = (config_t *)data;

	set_proc_title("dispatch");

db_fail: conn = mysql_init(NULL);

	mysql_real_connect(conn, (const char *) cfg->db_host,
			(const char *) cfg->db_user,
			(const char *) cfg->db_pass,
			(const char *) cfg->db_name, 0, NULL, 0);
	if (conn == NULL) {
		log_err("mysql_real_connect() failed");
		goto db_fail;
	}

	if (!mysql_set_character_set(conn, "gbk")) {
		log_err("charset %s", mysql_character_set_name(conn));
	}

	log_err("dispatch process [%ld]", getpid());

	for (;;) {
		row_cnt = get_batch_count(conn);
		if (row_cnt > 0) {
			if (dispatch_task(conn, cfg, row_cnt) == -2) {
				log_err("dispatch_task() failed");
				goto db_fail;
			}
		} else if (row_cnt == -2) {
			log_err("db failed");
			goto db_fail;
		} else {
			sleep(cfg->sleep_time);
			log_err("sleep,time [%d]", cfg->sleep_time);
			continue;
		}
	}

	return 0;
}

void create_worker_process(config_t *cfg)
{
	int i;
	
	char batch_status = ':';
	
	log_err("process_nums = %d",cfg->process_nums);

	for (i = 0; i < cfg->process_nums; i++) {
		cfg->status_idx = i;
		cfg->batch_status[i] = processes[i].batch_status = batch_status++;
		processes[i].pid = spawn_process(make_label,cfg);
		processes[i].proc = make_label;
		processes[i].name = "make_label";
		processes[i].respawn = -1;
	}

	processes[i].pid = spawn_process(dispatch_cycle,cfg);
	processes[i].proc = dispatch_cycle;
	processes[i].name = "dispatch_cycle";
	processes[i].respawn = -1;
}

void respawn_worker_process(config_t *cfg)
{
	int i;
	
	/* respawn worker */
	for (i = 0; i < cfg->process_nums; i++) {
		if (processes[i].respawn > 0)
		{
			cfg->status_idx = i;
			cfg->batch_status[i] = processes[i].batch_status;
			log_err("respawn batch_status %c",cfg->batch_status[i]);
			processes[i].pid = spawn_process(processes[i].proc,cfg);
			processes[i].respawn = -1;
		}
	}

	/* respawn dispather */
	if (processes[cfg->process_nums].respawn > 0) {
			processes[i].pid = spawn_process(processes[i].proc,cfg);
			processes[i].respawn = -1;
	}
}

void main_process_cycle(config_t *cfg)
{
	sigset_t set;

	set_proc_title("parent");

	sigemptyset(&set);

	sigaddset(&set, SIGCHLD);
	sigaddset(&set, SIGHUP);
	sigaddset(&set, SIGWINCH);
	sigaddset(&set, SIGTERM);
	sigaddset(&set, SIGQUIT);
	sigaddset(&set, SIGIO);
	sigaddset(&set, SIGINT);
	sigaddset(&set, SIGUSR1);
	sigaddset(&set, SIGUSR2);

	if (sigprocmask(SIG_BLOCK, &set, NULL) == -1) {
		log_err("sigprocmask() failed");
	}

	sigemptyset(&set);

	create_worker_process(cfg);

	/* monitoring loop */
	for (;;) {
		sigsuspend(&set);

		if (reap_child) {
			respawn_worker_process(cfg);
		}

		if (reload_config) {
			log_err("*** load_config ***");
			load_config(&config);
		}
	}
}

pid_t spawn_process(process_pt proc, void *data)
{
	pid_t pid;

	pid = fork();

	switch (pid) {
	case -1:
		log_err("spawn child failed");
		return -1;
	case 0:
		proc(data);
		break;
	default:
		break;
	}

	return pid;
}

void signal_handler(int signo)
{
	signal_t *sig;

	for (sig = signals; sig->signo != 0; sig++) {
		if (sig->signo == signo) {
			break;
		}
	}

	switch (signo) {
	case SIGQUIT:
		break;
	case SIGTERM:
	case SIGINT:
		break;
	case SIGWINCH:
		break;
	case SIGHUP:
		reload_config = 1;
		break;
	case SIGUSR1:
	case SIGUSR2:
		break;
	case SIGIO:
		break;
	case SIGCHLD:
		reap_child = 1;
		break;
	}

	log_err("signal [%d] (%s) received", signo, sig->signame);

	if (signo == SIGCHLD) {
		process_get_status();
	}
}

void process_get_status(void)
{
	int status;
	char *process;
	pid_t pid;
	int err;
	int i;
	unsigned int one;

	one = 0;

	for (;;) {
		pid = waitpid(-1, &status, WNOHANG);
		if (pid == 0) {
			return;
		}

		if (pid == -1) {
			err = errno;

			if (err == EINTR) {
				continue;
			}

			if (err == ECHILD && one) {
				return;
			}

			log_err("[%d][%s]", err, "waitpid() failed");
			return;
		}

		log_err("exit process pid = [%d]", pid);

		one = 1;
		process = "unknown process";

		for (i = 0; i < config.process_nums + 1; i++) {
			if (processes[i].pid == pid) {

				log_err("find one process");
				process = processes[i].name;
				processes[i].respawn = 1;
				break;
			}
		}

		if (WTERMSIG(status)) {
#ifdef WCOREDUMP
			log_err("%s %d exited on signal %d%s",
				process,
				pid,
				WTERMSIG(status),
				WCOREDUMP(status) ? " (core dumped)" : "");
#else
			log_err("%s %d exited on signal %d", process, pid,
					WTERMSIG(status));
#endif

		} else {
			log_err("%s %d exited with code %d",
				process,
				pid,
				WEXITSTATUS(status));
		}

		if (WEXITSTATUS(status) == 2) {
			log_err("fatal,cannot be respawned");
		}
	}
}

int init_signals()
{
	signal_t *sig;
	struct sigaction sa;

	for (sig = signals; sig->signo != 0; sig++) {
		memset(&sa, 0, sizeof(struct sigaction));
		sa.sa_handler = sig->handler;
		sigemptyset(&sa.sa_mask);
		if (sigaction(sig->signo, &sa, NULL) == -1) {
			log_err("sigaction(%s) failed", sig->signame);
			return -1;
		}
	}

	return 0;
}

int abnormal_exit_process(MYSQL *conn)
{
	char sql[1024] = {0};

	snprintf(sql, sizeof(sql), "%s", "update batch_label "
		"set status = '3' where status != '2'");
	mysql_query(conn, sql);

	return 0;
}

