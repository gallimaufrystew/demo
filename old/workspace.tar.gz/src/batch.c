/*
 * batch.c
 *
 *  Created on: 2012-9-6
 *      Author: huxk
 */

#include "batch.h"
#include "qrdef.h"
#include "sql.h"

static int writePNG(QRcode *qrcode, const char *outfile)
{
	static FILE *fp; // avoid clobbering by setjmp.
	png_structp png_ptr;
	png_infop info_ptr;
	png_colorp palette;
	png_byte alpha_values[2];
	unsigned char *row, *p, *q;
	int x, y, xx, yy, bit;
	int realwidth;

	realwidth = (qrcode->width + margin * 2) * size;
	row = (unsigned char *) malloc((realwidth + 7) / 8);
	if (row == NULL) {
		fprintf(stderr, "Failed to allocate memory.\n");
		exit(EXIT_FAILURE);
	}

	if (outfile[0] == '-' && outfile[1] == '\0') {
		fp = stdout;
	} else {
		fp = fopen(outfile, "wb");
		if (fp == NULL) {
			fprintf(stderr, "Failed to create file: %s\n", outfile);
			perror(NULL);
			exit(EXIT_FAILURE);
		}
	}

	png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING,
		NULL,
		NULL,
		NULL);
	if (png_ptr == NULL) {
		fprintf(stderr, "Failed to initialize PNG writer.\n");
		exit(EXIT_FAILURE);
	}

	info_ptr = png_create_info_struct(png_ptr);
	if (info_ptr == NULL) {
		fprintf(stderr, "Failed to initialize PNG write.\n");
		exit(EXIT_FAILURE);
	}

	if (setjmp(png_jmpbuf(png_ptr))) {
		png_destroy_write_struct(&png_ptr, &info_ptr);
		fprintf(stderr, "Failed to write PNG image.\n");
		exit(EXIT_FAILURE);
	}

	palette = (png_colorp) malloc(sizeof(png_color) * 2);
	palette[0].red = fg_color[0];
	palette[0].green = fg_color[1];
	palette[0].blue = fg_color[2];
	palette[1].red = bg_color[0];
	palette[1].green = bg_color[1];
	palette[1].blue = bg_color[2];
	alpha_values[0] = fg_color[3];
	alpha_values[1] = bg_color[3];
	png_set_PLTE(png_ptr, info_ptr, palette, 2);
	png_set_tRNS(png_ptr, info_ptr, alpha_values, 2, NULL);

	png_init_io(png_ptr, fp);
	png_set_IHDR(png_ptr,
		info_ptr,
		realwidth,
		realwidth,
		1,
		PNG_COLOR_TYPE_PALETTE,
		PNG_INTERLACE_NONE,
		PNG_COMPRESSION_TYPE_DEFAULT,
		PNG_FILTER_TYPE_DEFAULT);
	png_set_pHYs(png_ptr,
		info_ptr,
		dpi * INCHES_PER_METER,
		dpi * INCHES_PER_METER,
		PNG_RESOLUTION_METER);
	png_write_info(png_ptr, info_ptr);

	/* top margin */
	memset(row, 0xff, (realwidth + 7) / 8);
	for (y = 0; y < margin * size; y++) {
		png_write_row(png_ptr, row);
	}

	/* data */
	p = qrcode->data;
	for (y = 0; y < qrcode->width; y++) {
		bit = 7;
		memset(row, 0xff, (realwidth + 7) / 8);
		q = row;
		q += margin * size / 8;
		bit = 7 - (margin * size % 8);
		for (x = 0; x < qrcode->width; x++) {
			for (xx = 0; xx < size; xx++) {
				*q ^= (*p & 1) << bit;
				bit--;
				if (bit < 0) {
					q++;
					bit = 7;
				}
			}
			p++;
		}
		for (yy = 0; yy < size; yy++) {
			png_write_row(png_ptr, row);
		}
	}
	/* bottom margin */
	memset(row, 0xff, (realwidth + 7) / 8);
	for (y = 0; y < margin * size; y++) {
		png_write_row(png_ptr, row);
	}

	png_write_end(png_ptr, info_ptr);
	png_destroy_write_struct(&png_ptr, &info_ptr);

	fclose(fp);
	free(row);

	return 0;
}

static QRcode *encode(const unsigned char *intext, int length)
{
	QRcode *code;

	if (micro) {
		if (eightbit) {
			code = QRcode_encodeDataMQR(length,
				intext,
				version,
				level);
		} else {
			code = QRcode_encodeStringMQR((char *) intext,
				version,
				level,
				hint,
				casesensitive);
		}
	} else {
		if (eightbit) {
			code = QRcode_encodeData(length,
				intext,
				version,
				level);
		} else {
			code = QRcode_encodeString((char *) intext,
				version,
				level,
				hint,
				casesensitive);
		}
	}

	return code;
}

static void qrencode(const unsigned char *intext,
	int length,
	const char *outfile)
{
	QRcode *qrcode;

	qrcode = encode(intext, length);
	if (qrcode == NULL) {
		perror("Failed to encode the input data");
		exit(EXIT_FAILURE);
	}

	/* just use png type */
	writePNG(qrcode, outfile);

	QRcode_free(qrcode);
}

/********************************************************************/

int get_col_idx(MYSQL_RES *res, key_idx_t *ki)
{
	unsigned int i;
	MYSQL_FIELD *fields;

	ki->cols = mysql_num_fields(res);
	fields = mysql_fetch_field(res);

	for (i = 0; i < MAX_SEL_COLS; i++) {
		ki->kidx[i].idx = -1;
	}

	for (i = 0; i < ki->cols; i++) {
		strcpy(ki->kidx[i].name, fields[i].name);
		ki->kidx[i].idx = i;
	}

	return 0;
}

/* call after mysql_fetch_row */
int get_col_len(MYSQL_RES *res, MYSQL_ROW linep, key_idx_t *ki)
{
	unsigned int i;
	//MYSQL_FIELD *fields;
	//unsigned int num_fields;
	unsigned long *lens;

	//num_fields = mysql_num_fields(res);
	//fields = mysql_fetch_field(res);
	lens = mysql_fetch_lengths(res);

	for (i = 0; i < ki->cols; i++) {
		ki->kidx[i].len = lens[i];
		ki->kidx[i].fldvp = linep[i];
	}

	return 0;
}

char* get_value(key_idx_t *kidx, char *fldname)
{
	unsigned int i;

	for (i = 0; i < kidx->cols; i++) {
		if (kidx->kidx[i].idx < 0)
			break;
		if (strcmp(kidx->kidx[i].name, fldname) == 0) {
			return kidx->kidx[i].fldvp;
		}
	}

	return NULL;
}

void update_status(MYSQL *conn,key_idx_t *pmain_map,char status)
{
	char sql[1024] = {0};

	if (status == 'i')
	{
		snprintf(sql, sizeof(sql), "update batch_label "
			"set status = '4' "
			"where id = '%s'",
			get_value(pmain_map, "id"));
	}
	else if (status == 'f')
	{
		snprintf(sql,sizeof(sql),
			"update batch_label "
			"set status = '3' "
			"where id = '%s'",
			get_value(pmain_map, "id"));
	}
	else if (status == 's')
	{
		snprintf(sql,sizeof(sql),
			"update batch_label "
			"set status = '2' "
			"where id = '%s'",
			get_value(pmain_map, "id"));
	}

	mysql_query(conn, sql);
}

int make_label(void *data)
{
	MYSQL *conn = NULL;
	MYSQL_RES *result;
	MYSQL_ROW line;
	int db_ret, ret;
	char sql[2048] = {0};

	key_idx_t main_map;

db_fail: conn = mysql_init(NULL);

	config_t *cfg = (config_t *) data;

	set_proc_title("make_png");
	
	log_err("one process %d process status %c",
		getpid(),
		cfg->batch_status[cfg->status_idx]);

	mysql_real_connect(conn,
		(const char *) cfg->db_host,
		(const char *) cfg->db_user,
		(const char *) cfg->db_pass,
		(const char *) cfg->db_name,
		0,
		NULL,
		0);
	if (conn == NULL) {
		log_err("mysql_real_connect() failed");
		goto db_fail;
	}

	if (!mysql_set_character_set(conn, "gbk")) {
		log_err("charset %s", mysql_character_set_name(conn));
	}

	abnormal_exit_process(conn);

	for (;;) {
		memset(sql, 0, sizeof(sql));
		snprintf(sql,sizeof(sql),
			select_batch_label_sql,
			cfg->batch_status[cfg->status_idx]);

		db_ret = mysql_query(conn, sql);
		if (db_ret == CR_SERVER_GONE_ERROR || db_ret == CR_SERVER_LOST) {
			log_err("sql failed:\n[%s]", select_batch_label_sql);
			mysql_close(conn);
			goto db_fail;
		}

		result = mysql_store_result(conn);

		if (mysql_num_rows(result) == 0)
		{
			log_err("sleep,time [%d]",cfg->sleep_time);
			sleep(cfg->sleep_time);
			continue;
		}

		get_col_idx(result, &main_map);

		while ((line = mysql_fetch_row(result))) {

			get_col_len(result, line, &main_map);

			update_status(conn,&main_map,'i');

			ret = make_label_pic(conn, &main_map, cfg);
			if (ret == -1) {
				log_err("make_label_pic() failed");
				update_status(conn,&main_map,'f');
				continue;
			}

			if (ret == -2) {
				log_err("db failed");
				mysql_close(conn);
				goto db_fail;
			}

			update_status(conn,&main_map,'s');
		}

		mysql_free_result(result);
	}

	mysql_close(conn);

	return 0;
}

void get_current_time(char *time_now)
{
	time_t curtime;
	struct tm *loctime;

	curtime = time(NULL);

	loctime = localtime(&curtime);
	strftime(time_now, 30, "%Y%m%d", loctime);

	return;
}

int make_one_png(MYSQL *conn,
	key_idx_t *p_pmap,
	config_t *cfg,
	char *prefix,
	char *fname,
	int fname_len)
{
	char sql[2048] = {0};
	u_char png_str[4096] = {0};
	int slen = 0;
	char buf[512] = {0};

	/* before update status */
	snprintf(sql, sizeof(sql), "update product_label "
		"set status = '3' "
		"where id = '%s'", get_value(p_pmap, "id"));

	mysql_query(conn, sql);

	// png input string
	slen = snprintf((char *) png_str,
		sizeof(png_str),
		"%s%s%s",
		cfg->product_label_uri,
		get_value(p_pmap, "id"),
		get_value(p_pmap, "urlkey"));

	// png file name
	snprintf(fname,fname_len,
		"%s%s.png",
		get_value(p_pmap, "product_id"),
		get_value(p_pmap, "id"));
	snprintf(buf,sizeof(buf),
		"%s%s",
		cfg->zip_file_prefix,
		fname);

	log_err("png_str = [%s],filename = [%s]", png_str, buf);

	if (margin < 0) {
		if (micro) {
			margin = 2;
		} else {
			margin = 4;
		}
	}

#if (0)
	// modify the hexvalue to
	// set the png bgcolor & fgcolor
	if (color_set(fg_color, "FF4500")) {
		log_err("invalid bcolor value");
	}

	if (color_set(bg_color, "FFF8DC")) {
		log_err("invalid fcolor value");
	}
#endif

	// generate QRcode
	qrencode(png_str, slen, buf);

	// after update status
	memset(sql, 0, sizeof(sql));
	snprintf(sql, sizeof(sql), "update product_label "
		"set status = '1' where id = '%s'",
		get_value(p_pmap, "id"));

	mysql_query(conn, sql);

	return 0;
}

uLong filetime(char *f, tm_zip *tmzip, uLong *dt)
{
	int ret = 0;
	struct stat s; /* results of stat() */
	struct tm* filedate;
	time_t tm_t = 0;

	if (strcmp(f, "-") != 0) {
		char name[256 + 1];
		int len = strlen(f);
		if (len > 256)
			len = 256;

		strncpy(name, f, 256 - 1);
		/**
		 * strncpy doesnt append the trailing NULL,
		 * of the string is too long.
		 */
		name[256] = '\0';

		if (name[len - 1] == '/')
			name[len - 1] = '\0';
		/* not all systems allow stat'ing a file with / appended */
		if (stat(name, &s) == 0) {
			tm_t = s.st_mtime;
			ret = 1;
		}
	}
	filedate = localtime(&tm_t);

	tmzip->tm_sec = filedate->tm_sec;
	tmzip->tm_min = filedate->tm_min;
	tmzip->tm_hour = filedate->tm_hour;
	tmzip->tm_mday = filedate->tm_mday;
	tmzip->tm_mon = filedate->tm_mon;
	tmzip->tm_year = filedate->tm_year;

	return ret;
}

int make_label_pic(MYSQL *conn, key_idx_t *pmain_map, config_t *cfg)
{
	MYSQL_ROW product_row;
	MYSQL_RES *result;
	int db_ret = 0;
	key_idx_t product_map;

	char zipfile[1024] = {0};
	char png_name[128] = {0};
	char png_path[512] = {0};
	int opt_compress_level = Z_DEFAULT_COMPRESSION;
	int zip_ret;
	zipFile zf = NULL;
	zip_fileinfo zi;

	char sql[2048] = {0};

	memset(zipfile, 0, sizeof(zipfile));
	snprintf(zipfile,
		sizeof(zipfile),
		"%s%s.zip",
		cfg->zip_file_prefix,
		get_value(pmain_map, "batch_no"));

	log_err("zip file = [%s]", zipfile);

	zf = zipOpen(zipfile, 0); //just overwritten
	if (zf == NULL) {
		log_err("zipOpen() \"%s\" failed", zipfile);
		return -1;
	}

	memset(&zi, 0, sizeof(zi));
	zi.tmz_date.tm_sec = zi.tmz_date.tm_min = zi.tmz_date.tm_hour = zi.tmz_date.tm_mday = zi.tmz_date.tm_mon = zi.tmz_date.tm_year = 0;
	zi.dosDate = 0;
	zi.internal_fa = 0;
	zi.external_fa = 0;
	filetime(zipfile, &zi.tmz_date, &zi.dosDate);

	// batch process
	memset(sql, 0, sizeof(sql));
	snprintf(sql, sizeof(sql), "select id, "
		"product_id,"
		"node_id,"
		"urlkey "
		"from product_label "
		"where mark_batch_code = '%s' and "
		"node_id = '%s' and "
		"type = '2'",
		get_value(pmain_map, "batch_no"),
		get_value(pmain_map, "node_id"));

	log_err("product_label = [%s]", sql);

	db_ret = mysql_query(conn, sql);
	if (db_ret == CR_SERVER_GONE_ERROR || db_ret == CR_SERVER_LOST) {
		log_err("mysql_query() failed");
		return -2;
	}

	result = mysql_store_result(conn);
	db_ret = mysql_errno(conn);
	if (result == NULL) {
		if (db_ret == CR_SERVER_GONE_ERROR || db_ret == CR_SERVER_LOST) {
			log_err("db failed");
			return -2;
		} else {
			log_err("select product_label failed %s", sql);
			return -1;
		}
	}

	get_col_idx(result, &product_map);

	while ((product_row = mysql_fetch_row(result))) {
		//int fd;
		char tmp_buf[4096] = {0};
		FILE *fp = NULL;
		long flen = 0;
		//struct stat statbuf;

		/**************************************************/
		get_col_len(result, product_row, &product_map);

		if (make_one_png(conn,
			&product_map,
			cfg,
			cfg->zip_file_prefix,
			png_name,
			sizeof(png_name))) {
			log_err("make_one_png() failed");
			return -1;
		}

		snprintf(png_path,sizeof(png_path),
			"%s%s",cfg->zip_file_prefix,png_name);
		log_err("png_path = [%s]",png_path);
		if ((fp = fopen(png_path, "rb")) == NULL) {
			log_err("fopen() failed");
			return -1;
		}

		fseek(fp, 0, SEEK_END);

		flen = ftell(fp);
		log_err("png flen = [%ld]", flen);

		fseek(fp, 0, SEEK_SET);
		memset(tmp_buf, 0, sizeof(tmp_buf));
		fread(tmp_buf, flen, 1, fp);

		/**************************************************/
		zip_ret = zipOpenNewFileInZip(zf,
			png_name,
			&zi,
			NULL,
			0,
			NULL,
			0,
			NULL,
			(opt_compress_level != 0) ? Z_DEFLATED : 0,
			opt_compress_level);

		zip_ret = zipWriteInFileInZip(zf, tmp_buf, flen);
		if (zip_ret < 0) {
			log_err("zipWriteInFileInZip() failed.");
			fclose(fp);
			zipCloseFileInZip(zf);
			zipClose(zf, NULL);
			return -1;
		}

		/**************************************************/
		//munmap((void *) addr, statbuf.st_size);
		/**************************************************/
		zipCloseFileInZip(zf);
		fclose(fp);
		/**************************************************/

		/**************************************************/
		remove(png_path);
		/**************************************************/

		snprintf(sql,sizeof(sql),
			"update batch_label "
			"set file_name = '%s.zip',"
			"succ_num = succ_num + 1 "
			"where id = '%s'",
			get_value(pmain_map, "batch_no"),
			get_value(pmain_map, "id"));

		mysql_query(conn, sql);
	}

	zipClose(zf, NULL);

	mysql_free_result(result);

	return 0;
}
